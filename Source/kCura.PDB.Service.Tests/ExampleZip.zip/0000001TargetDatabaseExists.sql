/*==========================INDICATE SCRIPT RESULTS =================================
==	RoundhousE expects an output indicating the results of running this script.	   ==
==																				   ==
==	1: Run scripts for "new" database											   ==
==	0: Don't run "new" database scripts											   ==
===================================================================================*/

IF NOT EXISTS (SELECT * FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = 'RHVersion') BEGIN
	SELECT 1
END ELSE BEGIN
	SELECT 0
END