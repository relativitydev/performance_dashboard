IF NOT EXISTS (SELECT * FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA = 'eddsdbo' AND TABLE_NAME = 'QoS_BullfrogWork')
BEGIN
	--this table is a lightweight lookup table of the artifactIDs.  It is used to count the number of records to be reviewed, and is used to allow a lookup of them by artifactID.
	CREATE TABLE eddsdbo.QoS_BullfrogWork
	(
		KBWID INT IDENTITY(1,1) PRIMARY KEY
		, IDConsumable INT
		, VRHID INT
	)
	CREATE NONCLUSTERED INDEX [IX_VRHID_IDConsumable] ON eddsdbo.QoS_BullfrogWork
	(
		VRHID ASC,
		IDConsumable ASC
	)
END

IF NOT EXISTS(SELECT TABLE_NAME FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA = 'eddsdbo' AND  TABLE_NAME = 'QoS_BullfrogIDCWords')
BEGIN
	CREATE TABLE eddsdbo.QoS_BullfrogIDCWords
	(
		WordID INT IDENTITY (1,1),
		VRHID INT,
		KBWID INT,
		IDConsumable INT, 
		Word nvarchar(100), -- this is here only as a reference - it should never be used as it will not be nearly so fast to search this as to search the word table, which is the normal form of this column.
		Position INT
	)
	CREATE CLUSTERED INDEX [CI_IDConsumable_WordID] ON eddsdbo.QoS_BullfrogIDCWords
	(
		IDConsumable ASC,
		[WordID] ASC
	)
	CREATE NONCLUSTERED INDEX [IX_Word] ON eddsdbo.QoS_BullfrogIDCWords
	(
		[Word] ASC
	)
	CREATE NONCLUSTERED INDEX NCI_VRHID on eddsdbo.QoS_BullfrogIDCWords
	(
		[VRHID] ASC
	) INCLUDE (KBWID, IDConsumable, Word)
END

IF NOT EXISTS(SELECT TABLE_NAME FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA = 'eddsdbo' AND  TABLE_NAME = 'QoS_BullfrogWords')
BEGIN
	--this table will store a unique list of words, this is your dictionary.
	CREATE TABLE eddsdbo.QoS_BullfrogWords  
	(
		WordID INT IDENTITY(1,1),
		VRHID INT,
		Word nvarchar(100),
		BackWord nvarchar(100) -- not used yet
	)
	CREATE CLUSTERED INDEX [CI_WordID] ON eddsdbo.QoS_BullfrogWords
	(
		[WordID] ASC
	)
	CREATE NONCLUSTERED INDEX [NCI_VRHID] ON eddsdbo.QoS_BullfrogWords
	(
		[VRHID] ASC
	)
	CREATE NONCLUSTERED INDEX [NCI_Word] ON eddsdbo.QoS_BullfrogWords
	(
		[Word] ASC
	)
END

IF NOT EXISTS ( SELECT TABLE_NAME FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = 'QoS_ALLSearchzSubSearches' AND TABLE_SCHEMA = 'EDDSDBO' )
BEGIN
	CREATE TABLE eddsdbo.QoS_ALLSearchzSubSearches
    (
        AtSSSID INT IDENTITY(1, 1) ,
        PRIMARY KEY ( AtSSSID ) ,
		VRHID INT,
        ALLSearchz INT
    )
	CREATE NONCLUSTERED INDEX [NCI_VRHID] ON eddsdbo.QoS_ALLSearchzSubSearches
	(
		[VRHID] ASC
	) INCLUDE (ALLSearchz)
END

IF NOT EXISTS ( SELECT TABLE_NAME FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = 'QoS_thisSearchzSubSearches' AND TABLE_SCHEMA = 'EDDSDBO' )
BEGIN
	--create a table to use as the seed to find the next set of sub searcher in the inner while loop.	
	CREATE TABLE eddsdbo.QoS_thisSearchzSubSearches
    (
        tSSSID INT IDENTITY(1, 1) ,
        PRIMARY KEY ( tSSSID ) ,
		VRHID INT,
        SearchzSearchz INT
    )
	CREATE NONCLUSTERED INDEX [NCI_VRHID] ON eddsdbo.QoS_thisSearchzSubSearches
	(
		[VRHID] ASC
	) INCLUDE (SearchzSearchz)
END

IF NOT EXISTS ( SELECT TABLE_NAME FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = 'QoS_thisSearchzSubSearchesTemp' AND TABLE_SCHEMA = 'EDDSDBO' )
BEGIN
	CREATE TABLE eddsdbo.QoS_thisSearchzSubSearchesTemp
    (
        tSSSTID INT IDENTITY(1, 1) ,
        PRIMARY KEY ( tSSSTID ) ,
		VRHID INT,
        SearchzSearchz INT
    )
	CREATE NONCLUSTERED INDEX [NCI_VRHID] ON eddsdbo.QoS_thisSearchzSubSearchesTemp
	(
		[VRHID] ASC
	) INCLUDE (SearchzSearchz)
END

IF NOT EXISTS ( SELECT TABLE_NAME FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = 'QoS_Round2AllSearchzSubSearches' AND TABLE_SCHEMA = 'EDDSDBO' )
BEGIN
	CREATE TABLE eddsdbo.QoS_Round2AllSearchzSubSearches
    (
        AtSSSID INT IDENTITY(1, 1) ,
        PRIMARY KEY ( AtSSSID ) ,
		VRHID INT,
        ALLSearchz INT
    )
	CREATE NONCLUSTERED INDEX [NCI_VRHID] ON eddsdbo.QoS_Round2AllSearchzSubSearches
	(
		[VRHID] ASC
	) INCLUDE (ALLSearchz)
END

IF NOT EXISTS ( SELECT TABLE_NAME FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = 'QoS_SearchAuditRows' AND TABLE_SCHEMA = 'EDDSDBO' )
BEGIN
	CREATE TABLE eddsdbo.QoS_SearchAuditRows
    (
        TaRID INT IDENTITY(1, 1) ,
        PRIMARY KEY ( TaRID ) ,
		VRHID INT,
        AuditID BIGINT ,
        ArtifactID INT ,
        Details NVARCHAR(MAX) ,
        UserID INT ,
        [TimeStamp] [DATETIME] ,
        [Action] INT ,
        ExecutionTime INT ,
        RequestOrigination NVARCHAR(MAX)
    )
	CREATE NONCLUSTERED INDEX [NCI_VRHID_ArtifactID] ON eddsdbo.QoS_SearchAuditRows
	(
		[VRHID] ASC,
		[ArtifactID] ASC
	) INCLUDE (ExecutionTime, Details, AuditID)
END

IF NOT EXISTS ( SELECT TABLE_NAME FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = 'QoS_SearchAuditParsed' AND TABLE_SCHEMA = 'EDDSDBO' )
BEGIN
	CREATE TABLE eddsdbo.QoS_SearchAuditParsed
    (
        kSAPID INT IDENTITY(1, 1) ,
        PRIMARY KEY ( kSAPID ) ,
		VRHID INT,
        searchAuditID INT ,
        AuditID BIGINT,
        DetailsParsed NVARCHAR(MAX) ,
        IsHashJoin BIT
    )
	CREATE NONCLUSTERED INDEX [NCI_VRHID] ON eddsdbo.QoS_SearchAuditParsed
	(
		[VRHID] ASC
	)
END

IF NOT EXISTS ( SELECT TABLE_NAME FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = 'QoS_RSSDOutput' AND TABLE_SCHEMA = 'EDDSDBO' )
BEGIN
	CREATE TABLE eddsdbo.QoS_RSSDOutput
    (
        RSSDOID INT IDENTITY(1, 1) ,
        PRIMARY KEY ( RSSDOID ) ,
		VRHID INT,
        ArtifactID INT ,
        TotalRuns INT ,
        MaxRunsBySingleUser INT ,
        MaxRunsUser VARCHAR(200) ,
        userartifactID INT
    )
	CREATE NONCLUSTERED INDEX [NCI_VRHID] ON eddsdbo.QoS_RSSDOutput
	(
		[VRHID] ASC
	) INCLUDE (ArtifactID)
END

IF NOT EXISTS ( SELECT TABLE_NAME FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = 'QoS_RSSDUserOutput' AND TABLE_SCHEMA = 'EDDSDBO' )
BEGIN
	CREATE TABLE eddsdbo.QoS_RSSDUserOutput
    (
        RSSDuOID INT IDENTITY(1, 1) ,
        PRIMARY KEY ( RSSDuOID ) ,
		VRHID INT,
        ArtifactID INT ,
        RunBy VARCHAR(200) ,
        userartifactID INT ,
        TotalRunsbyUser INT
    )
	CREATE NONCLUSTERED INDEX [NCI_VRHID] ON eddsdbo.QoS_RSSDUserOutput
	(
		[VRHID] ASC,
		[ArtifactID] ASC
	)
END

IF NOT EXISTS ( SELECT TABLE_NAME FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = 'QoS_SSComplexity' AND TABLE_SCHEMA = 'EDDSDBO' )
BEGIN
	CREATE TABLE eddsdbo.QoS_SSComplexity
    (
        SSCID INT IDENTITY(1, 1) ,
        PRIMARY KEY ( SSCID ) ,
		VRHID INT,
        viewCriteriaID INT ,
        ArtifactID INT ,
        FullName NVARCHAR(200) ,
        CreatedOn DATETIME,
        Value NVARCHAR(MAX) ,
        ArtifactViewFieldID INT ,
        ColumnName VARCHAR(400) ,
        Operator VARCHAR(50) ,
        QueryHint VARCHAR(MAX) ,
        TextIdentifier NVARCHAR(500) ,
        SearchTextLength INT ,
        SearchText NVARCHAR(MAX) ,
        SearchFieldTypeID INT  -- this is duplicative of artifactViewFieldID and should be removed. 
	)

	CREATE NONCLUSTERED INDEX [NCI_VRHID_ArtifactID_ViewCriteriaID] ON [EDDSDBO].[QoS_SSComplexity]
	(
		[VRHID] ASC,
		[ArtifactID] ASC,
		[viewCriteriaID] ASC
	)
	INCLUDE ([Operator], [CreatedOn], [TextIdentifier], [FullName], [SearchText], [SearchFieldTypeID], [ColumnName], [Value])
END

IF NOT EXISTS ( SELECT TABLE_NAME FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = 'QoS_SSComplexityAnalysis' AND TABLE_SCHEMA = 'EDDSDBO' )
BEGIN
	CREATE TABLE eddsdbo.QoS_SSComplexityAnalysis
    (
        kSSCAID INT IDENTITY(1, 1) ,
        PRIMARY KEY ( kSSCAID ) ,
		VRHID INT,
        SearchArtifactID INT ,
        isChild BIT ,
        isCLRQ BIT ,
        SearchName NVARCHAR(MAX) ,
        LongestRunTime INT ,
        ShortestRunTime INT ,
        TotalLRQRunTime INT ,
        CreatedBy NVARCHAR(200) ,
        DateCreated DATETIME ,
        RelationalItemsIncluded NVARCHAR(100) ,
        ParsedSearchText NVARCHAR(MAX) , --5. this will contain any text that has been placed into the search text field.  THere can be only one.
        searchTextLength INT ,  --6. NOTE This is informational only, and is not used as part of the complexity scoring at this time.	
        isFullTextSearch BIT ,  --7. this gets set if there is a contains operator or if the ParsedSearchText field is greter than 0
        searchConditioniFTCLength INT ,  --8  This number is divided by 500.  1 point is added to the complexity score for every increment of 500.
        ConditionValue NVARCHAR(MAX) , --8.1 this is the actual value of the condition that has been entered.  
        QTYFullTextSearch INT ,  --9 All conditions that use the contains operator are given 1 point each.
        IsDTsearch BIT , --10.
        IsSQLSearch BIT , --11. if the search is not a contains or a dtsearch
        QTYLikeOperators INT , --12.
        QTYConditionValueWords INT , --13.
        QTYItemsIniFTS INT ,--14. The total number of columns built into the full text catalog.
        QTYsearchTextWords INT ,--15. This is the total number of words/items in the entire search. If the search text length is longer than 15, and it is a phrase, then what? THE EXACT DIFFERENCE THAT sql MIGHT HAVE BETWEEN SEARCHING FOR A SINGLE WORD OR A PHRASE IS UNKNOWN	
        dtSearchTextLength INT ,	--16.
        QTYFolderedSearch INT , --17.
        QTYNonLikes INT , --18.
        QTYOrderBy INT , --19.
        QtyOrderByIndexed INT ,
        SearchFieldTypes VARCHAR(500) ,
        OrderedByFieldTypes VARCHAR(500) ,
        OrderedByFields NVARCHAR(250) ,
        SearchFieldNames NVARCHAR(MAX) ,
        QTYIndexedSearchFields INT ,
        QTYSearchFields INT ,
        QTYSubSearches INT , --20.
        TotalQTYSubSearches INT , --21.
        TotalUniqueSubSearches INT , --22.
        LastQueryForm NVARCHAR(MAX) , --24.  This is the most recent version of the SQL that has been run.  It may not exactly match the conditions and settings because, potentially, the user may not have run the search after the last edit to it.  
        LongestRunningQueryForm NVARCHAR(MAX) ,
        TotalRunsDateRange INT , -- 25. The total number of times this search has been run in the date range that you entered.
        SearchHybridType NVARCHAR(30) , --IsHybrid, --if the search combines a dt search and a sql search
        totalSearchComplexityScore INT ,
        NumCancelled INT ,
        NumErrored INT
    )
	
	CREATE NONCLUSTERED INDEX [NCI_VRHID] ON eddsdbo.QoS_SSComplexityAnalysis
	(
		[VRHID] ASC,
		[SearchArtifactID] ASC
	) INCLUDE (ParsedSearchText, isFullTextSearch, isDTSearch, searchTextLength, QTYIndexedSearchFields)

	CREATE NONCLUSTERED INDEX [NCI_SearchArtifactID_VRHID] ON eddsdbo.QoS_SSComplexityAnalysis
	(
		[SearchArtifactID] ASC,
		[VRHID] ASC
	)
END

IF NOT EXISTS ( SELECT TABLE_NAME FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = 'QoS_vScAT_examinedSearchz' AND TABLE_SCHEMA = 'EDDSDBO' )
BEGIN
	CREATE TABLE eddsdbo.QoS_vScAT_examinedSearchz
	(
		[ID] [INT] IDENTITY(1, 1) ,  PRIMARY KEY ( ID ) ,
		VRHID INT,
		SearchArtifactID INT,
		totalSearches INT,
		totalUniqueSearches INT
	)
	CREATE NONCLUSTERED INDEX [NCI_VRHID] ON eddsdbo.QoS_vScAT_examinedSearchz
	(
		[VRHID] ASC
	) INCLUDE (SearchArtifactID)
END

IF NOT EXISTS ( SELECT TABLE_NAME FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = 'QoS_SubSearchCount' AND TABLE_SCHEMA = 'EDDSDBO' )
BEGIN
	CREATE TABLE eddsdbo.QoS_SubSearchCount
	(
		[ID] INT IDENTITY(1,1), PRIMARY KEY (ID),
		VRHID INT,
		SearchArtifactID INT,
		DOOP INT,
		SearchAsCriteriaArtifactID INT,
		[Level] INT
	)
	CREATE NONCLUSTERED INDEX [NCI_VRHID] ON eddsdbo.QoS_SubSearchCount
	(
		[VRHID] ASC
	)
END

IF NOT EXISTS ( SELECT TABLE_NAME FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = 'VarscatOutputDetail' AND TABLE_SCHEMA = 'EDDSDBO' )
BEGIN
	CREATE TABLE eddsdbo.VarscatOutputDetail
	(
		VODID INT
		IDENTITY(1, 1)
		PRIMARY KEY ( VODID ) ,
		VRHID INT,
		ServerName NVARCHAR(255) ,
		QoSHourID BIGINT ,
		DatabaseName NVARCHAR(128) ,
		SearchArtifactID INT,
		QueryID UNIQUEIDENTIFIER,
		SearchName NVARCHAR(max),
		AuditID BIGINT ,
		UserID INT ,
		ComplexityScore INT ,
		ExecutionTime INT ,--(rounded to nearest second unless it is less than 1, then it gets set to 1.)
		[Timestamp] DATETIME ,
		QoSAction INT ,
		--1	View
		--3	Update
		--281	Document Query (from audit action 28 - SELECT TOP)
		--282	Document Query (from audit action 28 - SELECT COUNT)
		--29	Query
		--32	Import
		--33	Export
		--34	ReportQuery
		--35	RelativityScriptExecution
		--47	RDC Imports
		--456 	Mass Actions (actions 4, 5, and 6 from AuditAction table combine to QoSAction 456)
		IsCount BIT ,
		IsComplex BIT ,
		IsLongRunning BIT ,
		IsErrored INT ,
		AgentID INT
	)
	CREATE NONCLUSTERED INDEX [NCI_VRHID] ON eddsdbo.VarscatOutputDetail (
		[VRHID] ASC
	)
	CREATE NONCLUSTERED INDEX [NCI_QoSHourID_Bound_Split] ON eddsdbo.VarscatOutputDetail (
		[QoSHourID] ASC,
		ExecutionTime ASC
	)
	INCLUDE (
		[UserID],
		[QoSAction]
	)
END

IF NOT EXISTS (SELECT TABLE_NAME FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = 'QoS_VarscatRunHistory' AND TABLE_SCHEMA = 'EDDSDBO')
BEGIN
	CREATE TABLE eddsdbo.QoS_VarscatRunHistory
	(
		VRHID INT IDENTITY(1, 1),
		PRIMARY KEY ( VRHID ),
		RunDateTimeUTC DATETIME,
		SummaryDayHour DATETIME,
		WhoRanMe NVARCHAR(100),
		IsActive BIT
	)
END