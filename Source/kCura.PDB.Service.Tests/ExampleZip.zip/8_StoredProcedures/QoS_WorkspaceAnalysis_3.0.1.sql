/****** kIE View And Recurring Search Complexity Analysis Tool - v 3.0.1
BRANCHED @:(VARSCAT) v 8.1.1.4  ******/
/*Author(s):	Client Services : kCura Infrastructure Engineering (kIE) Team
				Scott Ellis, Jared Lander, with much appreciated contributions from Nick Kapuza */
			
--WARNING: This is the install package and should only be run when performing an upgrade or an initial installation. 	
--NOTE check cancel queries configuration to see if its on...if it is off, then we don't know if it was saved or unsaved. it will always appear to be a saved search, so just don't report on that if cancel queries is off.  

--Remove old versions of VARSCAT
IF EXISTS (SELECT 1 FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[kIE_Varscat]') AND type = 'P')
    DROP PROCEDURE dbo.kIE_Varscat

IF EXISTS (SELECT 1 FROM sys.objects WHERE object_id = OBJECT_ID(N'[eddsdbo].[kIE_Varscat]') AND type = 'P')
    DROP PROCEDURE eddsdbo.kIE_Varscat

IF EXISTS (SELECT 1 FROM sys.objects WHERE object_id = OBJECT_ID(N'[eddsdbo].[QoS_Varscat]') AND type = 'P')
    DROP PROCEDURE eddsdbo.QoS_Varscat

IF EXISTS (SELECT 1 FROM sys.objects WHERE object_id = OBJECT_ID(N'[eddsdbo].[QoS_WorkspaceAnalysis]') AND type = 'P')
    DROP PROCEDURE eddsdbo.QoS_WorkspaceAnalysis
	
GO

CREATE PROCEDURE eddsdbo.QoS_WorkspaceAnalysis
    @msThreshold INT = 0 ,
    @beginDate DATETIME = '5/3/1987', --these defaults are logic dependent - do not change
    @endDate DATETIME = '5/3/1987', --these defaults are logic dependent - do not change
    @AgentID INT = -1,
    @QoSHourID BIGINT = 1,
    @logging BIT = 1,
    @EDDSPerformanceServer NVARCHAR(150) = ''
AS
BEGIN
	/****** kIE View And Recurring Search Complexity Analysis Tool (VARSCAT) v 8.1.3.0  ******/
	/*Author(s):	Client Services : kCura Infrastructure Engineering (kIE) Team
					Scott Ellis and Jared Lander with much appreciated contributions from Nick Kapuza */

    DECLARE
		@VSRunScope INT,
		@workspace NVARCHAR(128) = DB_NAME(),
		@LoggingVars NVARCHAR(MAX),
		@runStart DATETIME = GETUTCDATE(),
		@iMax INT,
		@i INT,
		@idoc INT,
		@doc NVARCHAR(MAX), 
		@AuditID BIGINT,
		@ItemsIniFTS INT,
		@x INT,
		@xMax INT,
		@o INT,
		@counto INT, --this is the count of searches
		@StringFieldOrderByTypes VARCHAR(500),
		@StringSearchFieldTypes VARCHAR(500),
		@StringSearchFieldNames NVARCHAR(MAX),	
		@SQL NVARCHAR(MAX),
		@CountToDelete INT,
		@runDiff INT,
		@rootWorkspaceArtifactID INT,
		@infoMessage NVARCHAR(MAX),
		@searchCount INT,
		@searchesInThisSearchCount INT, --the total number of searches in the examined search - "this" search 
		@examineMe INT, --this is the search being examined for sub searches
		@ouroboros INT,
		@historyKeepThreshold INT,
		@bullfrogKeepThreshold INT;

	SET @endDate = DATEADD(MI, 59, @beginDate)
	SET @endDate = DATEADD(SS, 59, @endDate)
	SET @endDate = DATEADD(MS, 997, @endDate)  --This is 997 because of the precision of DATETIME; 998 will round down to 997 and 999 will round up to the next hour.

	SET NOCOUNT ON
    SET XACT_ABORT ON

    IF @logging = 1
    BEGIN
        SET @LoggingVars = 'Starting (' + @workspace + ')';
        EXEC EDDSQoS.eddsdbo.QoS_LogAppend @EDDSPerformanceServer = @EDDSPerformanceServer,
            @runStartUTC = @runStart,
            @AgentID = @AgentID,
            @module = 'QoS_WorkspaceAnalysis',
            @taskCompleted = 'Beginning VARSCAT call.',
            @otherVars = @LoggingVars,
            @nextTask = 'Establish VARSCAT scope'
    END

	--create a run record
    INSERT INTO eddsdbo.QoS_VarscatRunHistory
		(RunDateTimeUTC, WhoRanMe, SummaryDayHour, IsActive)
    VALUES
		(GETUTCDATE(), ORIGINAL_LOGIN(), @beginDate, 1)

    SELECT @VSRunScope = SCOPE_IDENTITY()

	IF @logging = 1
	BEGIN
		SET @LoggingVars = @SQL
		EXEC EDDSQoS.eddsdbo.QoS_LogAppend
			@EDDSPerformanceServer = @EDDSPerformanceServer,
			@runStartUTC = @runStart,
			@AgentID = @AgentID,
			@module = 'QoS_WorkspaceAnalysis',
			@taskCompleted = 'Established VARSCAT scope',
			@otherVars = @LoggingVars,
			@nextTask = 'Initial cleanup work'
	END

	--We've locked down VARSCAT for this job, so any error that occurs from now on needs to result in setting IsActive to 0
    BEGIN TRY
        IF EXISTS (
			SELECT TOP 1 ID
            FROM eddsdbo.AuditRecord WITH(NOLOCK)
            WHERE [Action] IN ( 1, 3, 4, 5, 6, 28, 29, 32, 34, 35, 37 )
				AND [TimeStamp] >= @beginDate
				AND [Timestamp] < @endDate
		)
		BEGIN
            IF @logging = 1
            BEGIN
                SET @LoggingVars = '@beginDate = ' + CAST(@beginDate AS VARCHAR)
                EXEC EDDSQoS.eddsdbo.QoS_LogAppend @EDDSPerformanceServer = @EDDSPerformanceServer,
                    @runStartUTC = @runStart,
                    @AgentID = @AgentID,
                    @module = 'QoS_WorkspaceAnalysis',
                    @taskCompleted = 'Checked for activity',
                    @otherVars = @LoggingVars,
                    @nextTask = 'Perform cleanup tasks'
            END

			DELETE FROM EDDSQoS.eddsdbo.QoS_VarscatOutput
			WHERE QoSHourID = @QoSHourID
				AND DatabaseName = @workspace;
						
			DELETE FROM EDDSQoS.eddsdbo.QoS_VarscatOutputDetail
			WHERE QoSHourID = @QoSHourID
				AND DatabaseName = @workspace;

            IF @logging = 1
            BEGIN
                EXEC EDDSQoS.eddsdbo.QoS_LogAppend @EDDSPerformanceServer = @EDDSPerformanceServer,
                    @runStartUTC = @runStart,
                    @AgentID = @AgentID,
                    @module = 'QoS_WorkspaceAnalysis',
                    @taskCompleted = 'Completed initial cleanup tasks',
                    @nextTask = 'Populate audit rows and parse XML for audit details.'
            END		

			SELECT TOP 1 @rootWorkspaceArtifactID = MIN(ArtifactID)
            FROM eddsdbo.Artifact WITH(NOLOCK)

            INSERT INTO eddsdbo.QoS_SearchAuditRows
				(VRHID, AuditID, ArtifactID, Details, UserID, [TimeStamp], [Action], ExecutionTime, RequestOrigination)
            SELECT
				@VSRunScope,
				a.ID,
                a.[ArtifactID],
                a.[Details],
                UserID,
                [TimeStamp],
                [Action],
                ExecutionTime,
                RequestOrigination
            FROM [eddsdbo].[AuditRecord] a WITH ( NOLOCK )
            WHERE a.[Action] = 28
				AND executiontime >= @msThreshold
				AND [TimeStamp] >= @beginDate
				AND [Timestamp] < @endDate
            ORDER BY [TimeStamp] DESC
            OPTION ( MAXDOP 2 )

			SET @i = 1;
			SET @iMax = -1;

			SELECT
				@i = MIN(TaRID),
				@iMax = MAX(TaRID)
			FROM eddsdbo.QoS_SearchAuditRows WITH(NOLOCK)
			WHERE VRHID = @VSRunScope

			--Begin inner loop to course through audit record table records for this case  
			WHILE ( @i <= @iMax )
			BEGIN
				SELECT
					@doc = sar.[Details],
					@AuditID = AuditID
				FROM eddsdbo.QoS_SearchAuditRows sar WITH(NOLOCK)
				WHERE sar.TaRID = @i
				OPTION ( MAXDOP 4 )

				EXEC sp_xml_preparedocument @idoc OUTPUT,
					@doc
		
				INSERT INTO eddsdbo.QoS_SearchAuditParsed
					(VRHID, SearchAuditID, AuditID, DetailsParsed, IsHashJoin)
				SELECT
					@VSRunScope,
					@i,
					@AuditID,
					querytext,
					NULL
				FROM OPENXML (@idoc, '/auditElement/QueryText',2)
				WITH (QueryText NVARCHAR(MAX) '.')
				EXEC sp_xml_removedocument @idoc

				SET @i = ISNULL(
					(SELECT MIN(TaRID)
						FROM eddsdbo.QoS_SearchAuditRows WITH(NOLOCK)
						WHERE VRHID = @VSRunScope
						AND TaRID > @i
				), @iMax + 1);
			END

            IF @logging = 1
            BEGIN
                EXEC EDDSQoS.eddsdbo.QoS_LogAppend @EDDSPerformanceServer = @EDDSPerformanceServer,
                    @runStartUTC = @runStart,
                    @AgentID = @AgentID,
                    @module = 'QoS_WorkspaceAnalysis',
                    @taskCompleted = 'Populated audit rows and parsed XML for audit details.',
                    @nextTask = 'Populate RSSDOutput, RSSDUserOutput, and set max runs by single user.'
            END	

			--Begin new stuff for testing Hash Joins
			--1 does the parsed query contain a hash join?
            UPDATE eddsdbo.QoS_SearchAuditParsed
            SET IsHashJoin = 1
            WHERE VRHID = @VSRunScope
				AND DetailsParsed LIKE '%hash join%' 

			--Get number of runs for each search
            INSERT INTO eddsdbo.QoS_RSSDOutput
				(VRHID, ArtifactID, TotalRuns)
            SELECT
				@VSRunScope,
				v.ArtifactID,
                COUNT(v.ArtifactID) AS TotalRuns
            FROM eddsdbo.QoS_SearchAuditRows kSAR WITH(NOLOCK)
            INNER JOIN eddsdbo.QoS_SearchAuditParsed kSAP WITH(NOLOCK)
				ON kSAR.AuditID = kSAP.AuditID
            LEFT JOIN eddsdbo.[View] v WITH(NOLOCK)
				ON v.ArtifactID = kSAR.ArtifactID
            WHERE kSAR.VRHID = @VSRunScope
				AND v.ArtifactID IS NOT NULL
            GROUP BY v.ArtifactID
            ORDER BY COUNT(v.ArtifactID) DESC

			--Get number of runs for each search-user pair
			INSERT INTO eddsdbo.QoS_RSSDUserOutput
				(VRHID, ArtifactID, RunBy, userartifactID, TotalRunsbyUser)
            SELECT
				@VSRunScope,
				kSAR.ArtifactID,
				AU.FullName,
				AU.UserID,
				COUNT(kSAR.UserID) TotalRunsByUser
            FROM eddsdbo.QoS_SearchAuditRows kSAR WITH(NOLOCK)
            INNER JOIN eddsdbo.QoS_SearchAuditParsed kSAP WITH(NOLOCK)
				ON kSAR.AuditID = kSAP.AuditID
            INNER JOIN eddsdbo.AuditUser AU WITH(NOLOCK)
				ON AU.UserID = kSAR.UserID
            LEFT JOIN eddsdbo.[View] v WITH(NOLOCK)
				ON v.ArtifactID = kSAR.ArtifactID
            WHERE kSAR.VRHID = @VSRunScope
				AND v.ArtifactID IS NOT NULL
            GROUP BY kSAR.ArtifactID, AU.FullName, AU.UserID
            ORDER BY COUNT(kSAR.UserID) DESC
											
			UPDATE eddsdbo.QoS_RSSDOutput
			SET
				MaxRunsBySingleUser = S.TotalRunsbyUser, 
				MaxRunsUser = S.RunBy, 
				userartifactID = s.userartifactID  
			FROM eddsdbo.QoS_RSSDOutput RSSDo WITH(NOLOCK) 
			JOIN (
				SELECT
					ArtifactID,
					RunBy,
					userartifactID,
					TotalRunsbyUser,
					ROW_NUMBER() OVER(PARTITION BY artifactID ORDER by TotalRunsByUser DESC) RK 
					FROM  eddsdbo.QoS_RSSDUserOutput WITH(NOLOCK)
			) AS S
				ON RSSDo.ArtifactID = S.ArtifactID
			WHERE RSSDo.VRHID = @VSRunScope
				AND RSSDo.ArtifactID = S.ArtifactID
				AND RK = 1

            IF @logging = 1
            BEGIN
                EXEC EDDSQoS.eddsdbo.QoS_LogAppend @EDDSPerformanceServer = @EDDSPerformanceServer,
                    @runStartUTC = @runStart,
                    @AgentID = @AgentID,
                    @module = 'QoS_WorkspaceAnalysis',
                    @taskCompleted = 'Populated RSSDOutput, RSSDUserOutput, and set max runs by single user.',
                    @nextTask = 'Completed Step 1, loaded data to QoS_SSComplexity and QoS_SSComplexityAnalysis tables.'
            END	

            INSERT INTO eddsdbo.QoS_SSComplexity
				(VRHID, viewCriteriaID, ArtifactID, FullName, CreatedOn, Value, ArtifactViewFieldID, ColumnName, Operator, QueryHint, TextIdentifier, SearchTextLength, SearchText, SearchFieldTypeID)
            SELECT
				@VSRunScope,
				vc.viewCriteriaID,
                a.[ArtifactID] ,
                au.FullName ,
                a.CreatedOn ,
                vc.Value ,
                avf.ArtifactViewFieldID ,
                avf.ColumnName ,
                vc.Operator ,
                v.QueryHint ,
                a.TextIdentifier ,
                LEN(v.SearchText) SearchTextLength, -- 311
                v.SearchText ,
                v.[ArtifactTypeID]
			FROM eddsdbo.Artifact a WITH(NOLOCK)
            INNER JOIN eddsdbo.QoS_RSSDOutput RSSO WITH(NOLOCK)
				ON RSSO.ArtifactID = a.ArtifactID
            INNER JOIN eddsdbo.[View] v WITH(NOLOCK)
				ON a.ArtifactID = v.ArtifactID
            LEFT JOIN eddsdbo.ViewCriteria vc WITH(NOLOCK)
				ON v.ArtifactID = vc.viewID
            INNER JOIN eddsdbo.AuditUser au WITH(NOLOCK)
				ON a.CreatedBy = au.UserID
            LEFT JOIN eddsdbo.ArtifactViewField avf WITH(NOLOCK)
				ON vc.ArtifactViewFieldID = avf.ArtifactViewFieldID
			WHERE RSSO.VRHID = @VSRunScope
				AND v.ArtifactTypeID IN ( 10 )  --history artifacttypeid = 1000003

			--insert all subsearches
			/*The following insert presents some questions and needs to be modified.
			It needs to insert a row into the table for every search that is a child search, and it needs to insert it once and only once.
			The ss_complexity analysis search table should then have a column called "isChild" and "Parents" 
			It would be nice to have the Parents column contain a list of all of the ancestors of the child search.  
			Put the sub search counting stuff here....*/

			--Now fix bogus "Like" operator
            UPDATE eddsdbo.QoS_SSComplexity
            SET Operator = 'choiceSearch'
            FROM [eddsdbo].[ViewCriteria] VC WITH(NOLOCK)
            INNER JOIN [eddsdbo].[ExtendedField] F WITH(NOLOCK)
				ON F.ArtifactViewFieldID = VC.ArtifactViewFieldID
            WHERE VC.Operator = 'like'
				AND F.fieldTypeName IN ('Multiple Choice', 'Single Choice')
				AND eddsdbo.QoS_SSComplexity.VRHID = @VSRunScope
                AND eddsdbo.QoS_SSComplexity.viewCriteriaID = VC.viewCriteriaID;
  
			-- Sets a variable, @ItemsIniFTS, with the total number of fields in the full text catalog.
            SET @ItemsIniFTS = 1
            SELECT 
				@ItemsIniFTS = COUNT(*)
            FROM eddsdbo.Field WITH(NOLOCK)
            WHERE field.IsIndexEnabled = 1

            IF @ItemsIniFTS = 0
                SET @ItemsIniFTS = 1

            INSERT INTO eddsdbo.QoS_SSComplexityAnalysis
				(VRHID, SearchArtifactID)
            SELECT DISTINCT
				@VSRunScope,
                ArtifactID
            FROM eddsdbo.QoS_SSComplexity WITH(NOLOCK)
			WHERE VRHID = @VSRunScope

            SET @ouroboros = 912 --this is the maximum number of times the inner loop will run before deciding that there is a problem in the search that involves self-recursion (Ouroborus)

			--load up the sub-searchinSearch counts table with a distinct list of all searches that have a sub search
			--examinedSearchz is the list of root level searches, discovered in the audit record for this time range, that need to be examined.
            INSERT INTO eddsdbo.QoS_vScAT_examinedSearchz
				(VRHID, SearchArtifactID)
            SELECT DISTINCT
				@VSRunScope,
				searchArtifactID
            FROM eddsdbo.SearchSavedSearch WITH(NOLOCK)
            WHERE SearchArtifactID IN (
				SELECT SearchArtifactID
				FROM eddsdbo.QoS_SSComplexityAnalysis WITH(NOLOCK)
				WHERE VRHID = @VSRunScope
			)
	
			SET @o = 1;
			SET @searchCount = -1;
						
            SELECT
				@o = MIN(ID),
				@searchCount = MAX(ID)
            FROM eddsdbo.QoS_vScAT_examinedSearchz WITH(NOLOCK)
			WHERE VRHID = @VSRunScope

            IF @logging = 1
            BEGIN
                SET @LoggingVars = '@o = ' + CAST(@o AS VARCHAR) + ', @searchCount = ' + CAST(@searchCount AS VARCHAR);
                EXEC EDDSQoS.eddsdbo.QoS_LogAppend @EDDSPerformanceServer = @EDDSPerformanceServer,
                    @runStartUTC = @runStart,
                    @AgentID = @AgentID,
					@module = 'QoS_WorkspaceAnalysis',
                    @taskCompleted = 'Completed Step 1, loaded data to QoS_SSComplexity and QoS_SSComplexityAnalysis tables.',
                    @otherVars = @LoggingVars,
                    @nextTask = 'Begin round 1 sub-search analysis'
            END	

			--FIND ALL SEARCHs Sub-searches 
			--Cycle through each parent, then amass the total searches with a while loop that continually adds new sub-searches found to the list until it runs out. Then go on to the next search
            WHILE @o <= @searchCount
            BEGIN
				--Set the value of the Search to be examined
                SELECT @examineMe = SearchArtifactID
                FROM eddsdbo.QoS_vScAT_examinedSearchz WITH(NOLOCK)
                WHERE ID = @o

                SELECT @searchesInThisSearchCount = 0

				--get all of the children of this particular search
                INSERT INTO eddsdbo.QoS_thisSearchzSubSearches
					(VRHID, SearchzSearchz)
                SELECT
					@VSRunScope,
					searchAsCriteriaArtifactID
                FROM eddsdbo.SearchSavedSearch (NOLOCK)
                WHERE SearchArtifactID = @examineMe

                INSERT INTO eddsdbo.QoS_ALLSearchzSubSearches
					(VRHID, ALLSearchz)
                SELECT
					@VSRunScope,
					SearchzSearchz
				FROM eddsdbo.QoS_thisSearchzSubSearches WITH(NOLOCK)
				WHERE VRHID = @VSRunScope
	
                WHILE EXISTS (
						SELECT TOP 1 tSSSID
						FROM eddsdbo.QoS_thisSearchzSubSearches WITH(NOLOCK)
						WHERE VRHID = @VSRunScope
					) AND @searchesInThisSearchCount < @ouroboros
                BEGIN
					--grab the next set of searches to count.
                    SELECT @CountToDelete = COUNT(tSSSID)
                    FROM eddsdbo.QoS_thisSearchzSubSearches WITH(NOLOCK)
					WHERE VRHID = @VSRunScope

					--join to the searchSavedSearch table and insert into the QoS_ALLthisSearchzSubSearches
                    INSERT INTO eddsdbo.QoS_thisSearchzSubSearchesTemp
						(VRHID, SearchzSearchz)
                    SELECT
						@VSRunScope,
						sss.SearchAsCriteriaArtifactID
                    FROM eddsdbo.SearchSavedSearch sss WITH(NOLOCK)
                    INNER JOIN eddsdbo.QoS_thisSearchzSubSearches tsss WITH(NOLOCK)
						ON sss.SearchArtifactID = tsss.SearchzSearchz
					WHERE tsss.VRHID = @VSRunScope
                
					--next, insert it into the tracking table for this node
                    INSERT INTO eddsdbo.QoS_thisSearchzSubSearches
						(VRHID, SearchzSearchz)
                    SELECT
						@VSRunScope,
						SearchzSearchz
                    FROM eddsdbo.QoS_thisSearchzSubSearchesTemp WITH(NOLOCK)
					WHERE VRHID = @VSRunScope

                    INSERT INTO eddsdbo.QoS_ALLSearchzSubSearches
						(VRHID, ALLSearchz)
                    SELECT
						@VSRunScope, 
						SearchzSearchz
                    FROM eddsdbo.QoS_thisSearchzSubSearchesTemp WITH(NOLOCK)
					WHERE VRHID = @VSRunScope

                    SELECT @searchesInThisSearchCount += COUNT(tSSSTID)
                    FROM eddsdbo.QoS_thisSearchzSubSearchesTemp WITH(NOLOCK)
					WHERE VRHID = @VSRunScope

                    SET @SQL = 'DELETE FROM eddsdbo.QoS_thisSearchzSubSearches
						WHERE VRHID = ' + CAST(@VSRunScope AS NVARCHAR) + '
							AND tSSSID in (
								SELECT TOP ' + CAST(@CountToDelete AS NVARCHAR) + ' tSSSID
								FROM eddsdbo.QoS_thisSearchzSubSearches WITH(NOLOCK)
								WHERE VRHID = ' + CAST(@VSRunScope AS NVARCHAR) + '
								ORDER BY tSSSID ASC
							)'

                    EXEC sp_executesql @SQL

					--reseed the seed table 
                    DELETE FROM eddsdbo.QoS_thisSearchzSubSearchesTemp
					WHERE VRHID = @VSRunScope
                END
           
                UPDATE eddsdbo.QoS_vScAT_examinedSearchz
                SET
					totalSearches = @searchesInThisSearchCount ,
                    totalUniqueSearches = (
						SELECT COUNT(DISTINCT SearchzSearchz)
                        FROM eddsdbo.QoS_thisSearchzSubSearches WITH(NOLOCK)
						WHERE VRHID = @VSRunScope
                    )
                WHERE ID = @o 

                SET @o = ISNULL((SELECT MIN(ID)
					FROM eddsdbo.QoS_vScAT_examinedSearchz WITH(NOLOCK)
					WHERE VRHID = @VSRunScope
						AND ID > @o
				), @searchCount + 1);

                DELETE FROM eddsdbo.QoS_thisSearchzSubSearches
				WHERE VRHID = @VSRunScope
            END

            INSERT INTO eddsdbo.QoS_vScAT_examinedSearchz
				(VRHID, SearchArtifactID)
            SELECT DISTINCT
				@VSRunScope,
				ALLSearchz
            FROM eddsdbo.QoS_ALLSearchzSubSearches WITH(NOLOCK)
            WHERE VRHID = @VSRunScope
				AND ALLSearchz NOT IN (
                    SELECT ArtifactID
                    FROM eddsdbo.QoS_SSComplexity WITH(NOLOCK)
					WHERE VRHID = @VSRunScope
				)

            INSERT INTO eddsdbo.QoS_Round2AllSearchzSubSearches
				(VRHID, ALLSearchz)
            SELECT DISTINCT
				@VSRunScope,
                ALLSearchz
            FROM eddsdbo.QoS_ALLSearchzSubSearches WITH(NOLOCK)
            WHERE VRHID = @VSRunScope
				AND ALLSearchz NOT IN (
                    SELECT ArtifactID
                    FROM eddsdbo.QoS_SSComplexity WITH(NOLOCK)
					WHERE VRHID = @VSRunScope
				)

			--add in all the newly discovered subsearches to complexity and complexity analysis
            INSERT INTO eddsdbo.QoS_SSComplexity
				(VRHID, viewCriteriaID, ArtifactID, FullName, CreatedOn, Value, ArtifactViewFieldID, ColumnName, Operator, QueryHint, TextIdentifier, SearchTextLength, SearchText, SearchFieldTypeID)
            SELECT
				@VSRunScope,
				vc.viewCriteriaID ,
                a.[ArtifactID],
                au.FullName,
                a.CreatedOn,
                vc.Value,
                f.ArtifactViewFieldID,
                f.DisplayName,
                vc.Operator,
                v.QueryHint,
                a.TextIdentifier,
                LEN(v.SearchText) SearchTextLength,
                v.SearchText,
                f.FieldTypeID AS SearchFieldTypeID
            FROM eddsdbo.Artifact a WITH ( NOLOCK )
            INNER JOIN eddsdbo.[View] v WITH ( NOLOCK )
				ON a.ArtifactID = v.artifactid
            INNER JOIN eddsdbo.ViewCriteria vc WITH ( NOLOCK )
				ON v.artifactid = vc.viewID
            RIGHT JOIN eddsdbo.QoS_Round2AllSearchzSubSearches ASSS WITH(NOLOCK)
				ON ASSS.ALLSearchz = a.ArtifactID
            INNER JOIN eddsdbo.AuditUser au WITH ( NOLOCK )
				ON a.CreatedBy = au.UserID
            LEFT JOIN eddsdbo.field f WITH(NOLOCK)
				ON vc.ArtifactViewFieldID = f.ArtifactViewFieldID
            WHERE ASSS.VRHID = @VSRunScope
				AND v.ArtifactTypeID = 10
                AND ASSS.ALLSearchz NOT IN (
                    SELECT ArtifactID
                    FROM eddsdbo.QoS_SSComplexity WITH(NOLOCK)
					WHERE VRHID = @VSRunScope
				) 

			--Now move search complexity items into the analysis table
            INSERT INTO eddsdbo.QoS_SSComplexityAnalysis
				(VRHID, SearchArtifactID)
            SELECT DISTINCT
				@VSRunScope,
                k_SSC.ArtifactID
            FROM eddsdbo.QoS_SSComplexity k_SSC WITH(NOLOCK)
            WHERE VRHID = @VSRunScope
				AND ArtifactID IS NOT NULL
                AND k_SSC.ArtifactID NOT IN (
                    SELECT SearchArtifactID
                    FROM eddsdbo.QoS_SSComplexityAnalysis WITH(NOLOCK)
					WHERE VRHID = @VSRunScope
				) 

			--If the search appears in the subsearches table, mark it as a child search
            UPDATE eddsdbo.QoS_SSComplexityAnalysis
            SET isChild = 1
            WHERE VRHID = @VSRunScope
				AND SearchArtifactID IN (
                    SELECT ALLSearchz
                    FROM eddsdbo.QoS_Round2AllSearchzSubSearches WITH(NOLOCK)
					WHERE VRHID = @VSRunScope
				)

			--Step 1. SearchArtifactID Populate the analysis table with the IDs of the view and search artifactIDs
			--this should grow up and be a function someday--- ROUND 2 : this second iteration of this will only do the searches that were just added to complexity analysis.
            SET @o = 1;
			SET @searchCount = -1;
						
			IF @logging = 1
            BEGIN
                EXEC EDDSQoS.eddsdbo.QoS_LogAppend @EDDSPerformanceServer = @EDDSPerformanceServer,
                    @runStartUTC = @runStart,
                    @AgentID = @AgentID,
					@module = 'QoS_WorkspaceAnalysis',
                    @taskCompleted = 'Completed round 1 sub-search analysis',
                    @nextTask = 'Begin round 2 sub-search analysis'
            END	

			SELECT
				@o = MIN(AtSSSID),
				@searchCount = MAX(AtSSSID)
            FROM eddsdbo.QoS_Round2AllSearchzSubSearches WITH(NOLOCK)
			WHERE VRHID = @VSRunScope

            DELETE FROM eddsdbo.QoS_thisSearchzSubSearches
			WHERE VRHID = @VSRunScope

			--Cycle through each parent, then amass the total searches with a while loop that continually adds new sub-searches found to the list until it runs out. Then go on to the next search
            WHILE @o <= @searchCount
            BEGIN
				--Set the value of the Search to be examined
                SELECT @examineMe = ALLSearchz
                FROM eddsdbo.QoS_Round2AllSearchzSubSearches WITH(NOLOCK)
                WHERE AtSSSID = @o

                SELECT @searchesInThisSearchCount = 0

                INSERT INTO eddsdbo.QoS_thisSearchzSubSearches
					(VRHID, SearchzSearchz)
                SELECT
					@VSRunScope,
					SearchAsCriteriaArtifactID
                FROM eddsdbo.SearchSavedSearch WITH(NOLOCK)
                WHERE SearchArtifactID = @examineMe                

                WHILE EXISTS (SELECT TOP 1 tSSSID FROM eddsdbo.QoS_thisSearchzSubSearches WITH(NOLOCK) WHERE VRHID = @VSRunScope)
                    AND @searchesInThisSearchCount < @ouroboros
                BEGIN
					--grab the next set of searches to count.
                    SELECT @CountToDelete = COUNT(tSSSID)
                    FROM eddsdbo.QoS_thisSearchzSubSearches WITH(NOLOCK)
					WHERE VRHID = @VSRunScope

					--join to the searchSavedSearch table and insert into the QoS_ALLthisSearchzSubSearches
                    INSERT INTO eddsdbo.QoS_thisSearchzSubSearchesTemp
						(VRHID, SearchzSearchz)
                    SELECT
						@VSRunScope,
						sss.SearchAsCriteriaArtifactID
                    FROM eddsdbo.SearchSavedSearch sss WITH(NOLOCK)
                    INNER JOIN eddsdbo.QoS_thisSearchzSubSearches tsss WITH(NOLOCK)
						ON sss.SearchArtifactID = tsss.SearchzSearchz
					WHERE tsss.VRHID = @VSRunScope

					--next, insert it into the tracking table for this node
                    INSERT INTO eddsdbo.QoS_thisSearchzSubSearches
						(VRHID, SearchzSearchz)
                    SELECT
						@VSRunScope,
						SearchzSearchz
                    FROM eddsdbo.QoS_thisSearchzSubSearchesTemp WITH(NOLOCK)
					WHERE VRHID = @VSRunScope

                    SELECT @searchesInThisSearchCount += COUNT(tSSSTID)
                    FROM eddsdbo.QoS_thisSearchzSubSearchesTemp WITH(NOLOCK)
					WHERE VRHID = @VSRunScope
           
                    SET @SQL = 'DELETE FROM eddsdbo.QoS_thisSearchzSubSearches
					WHERE VRHID = ' + CAST(@VSRunScope AS NVARCHAR) + '
						AND tSSSID IN (
							SELECT TOP ' + CAST(@CountToDelete AS NVARCHAR) + ' tSSSID
							FROM eddsdbo.QoS_thisSearchzSubSearches WITH(NOLOCK)
							WHERE VRHID = ' + CAST(@VSRunScope AS NVARCHAR) + '
							ORDER BY tSSSID ASC
						)'
 
                    EXEC sp_executesql @SQL

					--reseed the seed table 
                    DELETE FROM eddsdbo.QoS_thisSearchzSubSearchesTemp
					WHERE VRHID = @VSRunScope
                END

                UPDATE eddsdbo.QoS_vScAT_examinedSearchz
                SET TotalSearches = @searchesInThisSearchCount,
					TotalUniqueSearches = (
						SELECT COUNT(DISTINCT SearchzSearchz)
                        FROM eddsdbo.QoS_thisSearchzSubSearches WITH(NOLOCK)
						WHERE VRHID = @VSRunScope
                    )
                WHERE VRHID = @VSRunScope
					AND SearchArtifactID = @examineMe

                SET @o = ISNULL((SELECT MIN(AtSSSID)
					FROM eddsdbo.QoS_Round2AllSearchzSubSearches WITH(NOLOCK)
					WHERE VRHID = @VSRunScope
						AND AtSSSID > @o
				), @searchCount + 1)

                DELETE FROM eddsdbo.QoS_thisSearchzSubSearches
				WHERE VRHID = @VSRunScope
            END
  
			--TotalQTYSubSearches & TotalQTYUniqueSubSearches: Gather up the total number of subSearches in any given search. 
			/* This number is all inclusive and counts every subsearch beyond the node, downward. It also tells you if there are any searches that 
			appear more than once in the tree. */
  
            UPDATE eddsdbo.QoS_SSComplexityAnalysis
            SET TotalQTYSubSearches = (
					SELECT totalSearches
					FROM eddsdbo.QoS_vScAT_examinedSearchz r WITH(NOLOCK)
					WHERE VRHID = @VSRunScope
						AND r.SearchArtifactID = eddsdbo.QoS_SSComplexityAnalysis.SearchArtifactID
				),
                TotalUniqueSubSearches = (
					SELECT totalUniqueSearches
                    FROM eddsdbo.QoS_vScAT_examinedSearchz r WITH(NOLOCK)
                    WHERE VRHID = @VSRunScope
						AND r.SearchArtifactID = eddsdbo.QoS_SSComplexityAnalysis.SearchArtifactID
                )
			WHERE VRHID = @VSRunScope

            IF @logging = 1
            BEGIN
                EXEC EDDSQoS.eddsdbo.QoS_LogAppend @EDDSPerformanceServer = @EDDSPerformanceServer,
                    @runStartUTC = @runStart,
                    @AgentID = @AgentID,
					@module = 'QoS_WorkspaceAnalysis',
                    @taskCompleted = 'Completed sub-search analysis.',
                    @nextTask = 'Steps 2 - 4 (See Varscat Comments)'
            END	

			--Insert the new, additional searches into the Complexity Analysis and Complexity tables

			--Steps 2-4 this will take several updates to do, so first take care of updating the values of all fields that will not be analyzed.
            UPDATE eddsdbo.QoS_SSComplexityAnalysis
            SET SearchName = ssc.TextIdentifier ,
                CreatedBy = ssc.FullName ,
                DateCreated = ssc.CreatedOn
            FROM eddsdbo.QoS_SSComplexity ssc WITH(NOLOCK)
            WHERE eddsdbo.QoS_SSComplexityAnalysis.VRHID = @VSRunScope
				AND ssc.VRHID = @VSRunScope
				AND eddsdbo.QoS_SSComplexityAnalysis.SearchArtifactID = ssc.ArtifactID

            UPDATE eddsdbo.QoS_SSComplexityAnalysis
            SET RelationalItemsIncluded = (
					SELECT f.FriendlyName
                    FROM eddsdbo.Field f WITH(NOLOCK)
                    INNER JOIN eddsdbo.[View] v WITH(NOLOCK)
						ON f.ArtifactID = v.ViewByFamily
                    INNER JOIN eddsdbo.QoS_SSComplexityAnalysis kSSCA WITH(NOLOCK)
						ON kSSCA.SearchArtifactID = v.ArtifactID
                    WHERE kSSCA.VRHID = @VSRunScope
						AND eddsdbo.QoS_SSComplexityAnalysis.SearchArtifactID = v.ArtifactID
                )
			WHERE VRHID = @VSRunScope
	
			-- Step 5. ParsedSearchText  Update the searchText field by processing the XML in the searchtext field. This will contain any text that has been placed into the search text field.  There can be only one.
            BEGIN TRY
				UPDATE ssca
				SET ssca.ParsedSearchText = (SELECT
						CASE WHEN SearchText LIKE '%SQLServer2005SearchProvider%'
							THEN ISNULL(CAST(SearchText AS XML).value('declare namespace CRUD="kCura.EDDS.SQLServer2005SearchProvider";(/InputData/CRUD:SearchText)[1]', 'nvarchar(max)'), '')
						WHEN SearchText LIKE '%DTSearchSearchProvider%'
							THEN ISNULL(CAST(SearchText AS XML).value('declare namespace CRUD="kCura.EDDS.DTSearchSearchProvider";(/InputData/CRUD:SearchText)[1]', 'nvarchar(max)'), '')
						WHEN SearchText LIKE '%ContentAnalystSearchProvider%'
							THEN ISNULL(CAST(SearchText AS XML).value('declare namespace CRUD="kCura.EDDS.ContentAnalystSearchProvider";(/InputData/CRUD:KeywordsText)[1]', 'nvarchar(max)'), '')
						WHEN SearchText LIKE '%ContentAnalystSearchProvider%'
							THEN ISNULL(CAST(SearchText AS XML).value('declare namespace CRUD="kCura.EDDS.ContentAnalystSearchProvider";(/InputData/CRUD:ConceptsText)[1]', 'nvarchar(max)'), '')
						END
					)
				FROM eddsdbo.QoS_SSComplexityAnalysis ssca
				INNER JOIN eddsdbo.QoS_SSComplexity C WITH(NOLOCK)
					ON ssca.VRHID = C.VRHID
						AND ssca.SearchArtifactID = C.ArtifactID
				INNER JOIN eddsdbo.QoS_SSComplexityAnalysis kssc WITH(NOLOCK)
					ON ssca.VRHID = kssc.VRHID
						AND C.ArtifactID = kssc.SearchArtifactID
				WHERE ssca.VRHID = @VSRunScope
					AND LEN(C.SearchText) > 0
            END TRY  
            BEGIN CATCH
				--One of the searches has invalid characters... To figure out which one, we'll iterate through them one at a time
				SET @x = 1;
				SET @xMax = -1;
				SET @i = 0;

                SELECT
					@x = MIN(kSSCAID),
					@xMax = MAX(kSSCAID)
                FROM eddsdbo.QoS_SSComplexityAnalysis WITH(NOLOCK)
				WHERE VRHID = @VSRunScope

                WHILE @x <= @xMax
                BEGIN
                    BEGIN TRY
						UPDATE ssca
						SET ssca.ParsedSearchText = (SELECT
								CASE WHEN SearchText LIKE '%SQLServer2005SearchProvider%'
									THEN ISNULL(CAST(SearchText AS XML).value('declare namespace CRUD="kCura.EDDS.SQLServer2005SearchProvider";(/InputData/CRUD:SearchText)[1]', 'nvarchar(max)'), '')
								WHEN SearchText LIKE '%DTSearchSearchProvider%'
									THEN ISNULL(CAST(SearchText AS XML).value('declare namespace CRUD="kCura.EDDS.DTSearchSearchProvider";(/InputData/CRUD:SearchText)[1]', 'nvarchar(max)'), '')
								WHEN SearchText LIKE '%ContentAnalystSearchProvider%'
									THEN ISNULL(CAST(SearchText AS XML).value('declare namespace CRUD="kCura.EDDS.ContentAnalystSearchProvider";(/InputData/CRUD:KeywordsText)[1]', 'nvarchar(max)'), '')
								WHEN SearchText LIKE '%ContentAnalystSearchProvider%'
									THEN ISNULL(CAST(SearchText AS XML).value('declare namespace CRUD="kCura.EDDS.ContentAnalystSearchProvider";(/InputData/CRUD:ConceptsText)[1]', 'nvarchar(max)'), '')
								END
							)
						FROM eddsdbo.QoS_SSComplexityAnalysis ssca
						INNER JOIN eddsdbo.QoS_SSComplexity C WITH(NOLOCK)
							ON ssca.SearchArtifactID = C.ArtifactID
						INNER JOIN eddsdbo.QoS_SSComplexityAnalysis kssc WITH(NOLOCK)
							ON C.ArtifactID = kssc.SearchArtifactID
						WHERE ssca.VRHID = @VSRunScope
							AND ssca.kSSCAID = @x
							AND LEN(C.SearchText) > 0					
                    END TRY
                    BEGIN CATCH
						SET @i += 1;

                        UPDATE eddsdbo.QoS_SSComplexityAnalysis
                        SET ParsedSearchText = 'There is an invalid character in this search''s text.  This search will not run and is not editable via the front end.  Remedy this by finding and removing the invalid character from the SearchText column on the eddsdbo.[View] table of the database for this workspace.  Contact kCura Client Services for assistance as needed.'
                        FROM eddsdbo.QoS_SSComplexityAnalysis kssc WITH(NOLOCK)
                        INNER JOIN eddsdbo.QoS_SSComplexity C WITH(NOLOCK)
							ON kssc.SearchArtifactID = C.ArtifactID
                        WHERE kssc.[kSSCAID] = @x
							AND LEN(C.SearchText) > 0

                        IF @logging = 1
                        BEGIN
                            SELECT TOP 1
								@loggingVars = 'SearchArtifactID = ' + CAST(SearchArtifactID AS VARCHAR) +
									', SearchName = ' + SearchName +
									', Invalid search text = '
                            FROM eddsdbo.QoS_SSComplexityAnalysis WITH(NOLOCK)
                            WHERE kSSCAID = @x

                            SELECT @loggingVars += C.SearchText
                            FROM eddsdbo.QoS_SSComplexity C WITH(NOLOCK)
                            INNER JOIN eddsdbo.QoS_SSComplexityAnalysis kssc WITH(NOLOCK)
								ON C.ArtifactID = kssc.SearchArtifactID
                            WHERE [kSSCAID] = @x
								AND LEN(SearchText) > 0

                            EXEC EDDSQoS.eddsdbo.QoS_LogAppend @EDDSPerformanceServer = @EDDSPerformanceServer,
                                @runStartUTC = @runStart,
                                @AgentID = @AgentID,
                                @module = 'QoS_WorkspaceAnalysis',
                                @taskCompleted = 'A search was found that contained bogus characters that would cause your search to fail. This search will not run and is not editable via the front end.  See the OtherVars column to identify the search exhibiting this issue.',
                                @otherVars = @LoggingVars,
                                @nextTask = 'Exit inner catch block for parsing search text from XML.  Resuming outer catch block in case there are more searches that exhibit this issue.'
                        END
                    END CATCH 
  	
                    SET @x = ISNULL((SELECT MIN(kSSCAID)
						FROM eddsdbo.QoS_SSComplexityAnalysis WITH(NOLOCK)
						WHERE VRHID = @VSRunScope
							AND kSSCAID > @x
					), @xMax + 1)
                END
  
                IF @logging = 1
                BEGIN
                    SELECT @loggingVars = 'Number of searches analyzed with invalid characters: ' + CAST(@i AS VARCHAR)
                    EXEC EDDSQoS.eddsdbo.QoS_LogAppend @EDDSPerformanceServer = @EDDSPerformanceServer,
                        @runStartUTC = @runStart,
                        @AgentID = @AgentID,
						@module = 'QoS_WorkspaceAnalysis',
                        @taskCompleted = 'Parsed search text from XML and checked for searches with invalid characters that could not be parsed.',
                        @otherVars = @LoggingVars,
                        @nextTask = 'Exit outer catch block for parsing search text from XML.'
                END	 
            END CATCH

            IF @logging = 1
            BEGIN
                EXEC EDDSQoS.eddsdbo.QoS_LogAppend @EDDSPerformanceServer = @EDDSPerformanceServer,
                    @runStartUTC = @runStart,
                    @AgentID = @AgentID,
					@module = 'QoS_WorkspaceAnalysis',
                    @taskCompleted = 'Steps 2 - 5 (See Varscat Comments)',
                    @otherVars = @LoggingVars,
                    @nextTask = 'Steps 6 - 12 (See Varscat Comments)'
            END	
  
			--Step 6. searchTextLength = eddsdbo.QoS_SSComplexityAnalysis len(ParsedSearchText) for information purposes only, and is not used in scoring.
            UPDATE eddsdbo.QoS_SSComplexityAnalysis
            SET searchTextLength = LEN(ParsedSearchText)
            WHERE VRHID = @VSRunScope
				AND ParsedSearchText IS NOT NULL
                AND ParsedSearchText != 'The following searches contain invalid characters in their search text '
                    + 'and will need to be fixed by removing the invalid characters from the SearchText column on the eddsdbo.[View] table.  Contact kCura Client Services for assistance as needed.'

			--Step 7. IsFullTextSearch : checks to see if any portion of the search is an iFTS search This is two items because if a search only uses the search text field, there will be no "contains" operator, but the searchText field wil be longer than normal and the operator field will be NULL (see second item).  
            UPDATE eddsdbo.QoS_SSComplexityAnalysis
            SET isFullTextSearch = (SELECT
					CASE WHEN operator = 'contains' THEN 1
						WHEN SearchText LIKE '%SQLServer2005SearchProvider%' THEN 1
					END
				)
            FROM eddsdbo.QoS_SSComplexity c WITH(NOLOCK)
            INNER JOIN eddsdbo.QoS_SSComplexityAnalysis kssc WITH(NOLOCK)
				ON c.ArtifactID = kssc.SearchArtifactID
				AND c.VRHID = kssc.VRHID
            WHERE c.VRHID = @VSRunScope
				AND kssc.searchTextLength > 0 

			--Step 8. searchConditioniFTCLength now get the sum lengths of the fielded searches, where they exist
            UPDATE eddsdbo.QoS_SSComplexityAnalysis
            SET searchConditioniFTCLength = SumSearchTextLength  --this is put here for informational purposes only and is not rolled into the complexity score at this time.
            FROM eddsdbo.QoS_SSComplexityAnalysis ksca WITH(NOLOCK)
            INNER JOIN (
				SELECT
					ArtifactID,
					SUM(LEN(ISNULL(Value, 0))) SumSearchTextLength
                FROM eddsdbo.QoS_SSComplexity WITH(NOLOCK)
                WHERE VRHID = @VSRunScope
					AND Operator = 'contains'
                GROUP BY ArtifactID
            ) sstl
				ON ksca.SearchArtifactID = sstl.ArtifactID
			WHERE VRHID = @VSRunScope
				AND ksca.VRHID = @VSRunScope

			--Step 9. QTYFullTextCatalogSearch:  if the search is against the entire catalog through the Search Text field, it is noted in a separate field. This only considers Conditions.	
            UPDATE eddsdbo.QoS_SSComplexityAnalysis
            SET QTYFullTextSearch = QUANTITY
            FROM eddsdbo.QoS_SSComplexityAnalysis ksca
            INNER JOIN (
				SELECT
					ArtifactID,
                    COUNT(*) QUANTITY
                FROM eddsdbo.QoS_SSComplexity WITH(NOLOCK)
                WHERE VRHID = @VSRunScope
					AND Operator = 'Contains'
                GROUP BY ArtifactID
            ) kssc
				ON ksca.SearchArtifactID = kssc.ArtifactID
			WHERE VRHID = @VSRunScope
				AND ksca.VRHID = @VSRunScope

			--searches done using the search text are treated separately, so this score only reflects the search CONDITIONs. 
			--Step 10. IsDTSearch, IsSQLSearch, QTYLikeOperators
			UPDATE ssca
			SET
				--Detects whether a search used dtSearch or not. 
				IsDTsearch = (
					SELECT TOP 1 1
					FROM eddsdbo.QoS_SSComplexity WITH(NOLOCK)
					WHERE VRHID = ssca.VRHID
						AND SearchText LIKE '%dtsearch%'
						AND ssca.SearchArtifactID = ArtifactID
				),
				--If there are any operators that are not "IN" or "CONTAINS", then it is a SQL search
				IsSQLSearch = (
					SELECT TOP 1 1
                    FROM eddsdbo.QoS_SSComplexity WITH(NOLOCK)
                    WHERE VRHID = ssca.VRHID
						AND Operator NOT IN ('IN', 'Contains')
						AND ssca.SearchArtifactID = ArtifactID
                ),
				--QTYLikeOperators analyze for LIKE searches.
				QTYLikeOperators = (
					SELECT COUNT(Operator)
                    FROM eddsdbo.QoS_SSComplexity WITH(NOLOCK)
                    WHERE VRHID = ssca.VRHID
						AND Operator = 'like'
                        AND ssca.SearchArtifactID = ArtifactID
                    GROUP BY ArtifactID
                )
			FROM eddsdbo.QoS_SSComplexityAnalysis ssca
			WHERE VRHID = @VSRunScope
	
			--Step 13. QTYConditionValueWords : this determines how many words are in the value field for a search condition.  It sums all conditions in a search.  this is separate from search text words.
			/* NOTE: Like searches are weighted with this variable.  If there are 4 words in a single like search, and the weight is set to four, then the final complexity score will be incremented b 16.  
			You may reduce this to '1' to determine what the score would be without like searches. By default, it is set to "10." */

            SET @o = 0

            IF @logging = 1
            BEGIN
                SET @LoggingVars = 'Exec EDDSDBO.QoS_Bullfrog 
					@fieldConsumable =''Value'',
					@tableConsumable = ''eddsdbo.QoS_SSComplexity'',
					@IDConsumable = ''ViewCriteriaID'',
					@wordBreak = '' ''
					,@excludeWords = ''''
					--other stuff
					,@EDDSPerformanceServer = ' + @EDDSPerformanceServer + '
					,@AgentID = ' + CAST(@AgentID AS VARCHAR) + '
					,@VSRunID = ' + CAST(@VSRunScope AS VARCHAR) + '
					,@Batchsize = 1000
					,@logging = 1
					,@withResume = 0'
                EXEC EDDSQoS.eddsdbo.QoS_LogAppend @EDDSPerformanceServer = @EDDSPerformanceServer,
                    @runStartUTC = @runStart,
                    @AgentID = @AgentID,
					@module = 'QoS_WorkspaceAnalysis',
                    @taskCompleted = 'Steps 6 - 13 (See Varscat Comments) completed.  Prepared QoS_Bullfrog call to consume QoS_SSComplexity Value field.',
                    @otherVars = @LoggingVars,
                    @nextTask = 'Preparing to Call QoS_Bullfrog to collect word counts in all conditions'
            END

            EXEC eddsdbo.QoS_Bullfrog --pass in whatever user configurable settings we want, here.  
                @fieldConsumable = 'Value',
                @tableConsumable = 'eddsdbo.QoS_SSComplexity',
                @IDConsumable = 'ViewCriteriaID',  -- input of the field name on the document table to be worked on. This is the column that will be consumed
                @wordBreak = ' ', -- this is the delimiters, which accepts a single delimiter (future version to accept a comma delimited list of delimiters)
                @excludeWords = '', -- Use a pipe delimiter for noise words!
                @EDDSPerformanceServer = @EDDSPerformanceServer,
                @AgentID = @AgentID,
                @VSRunID = @VSRunScope,
				@Batchsize = 1000,
                @logging = 1, -- for both carving and for the preload phase, this is the size of the transaction that will be committed.  For the preload phase, this is the size of the actual number of rows that will be inserted into the temp table to be worked on.  
                @withResume = 0 --Resume the operation. OK, so, if for some reason your attempt fails and you want it to pickup where you left off, set this to '1'.  Otherwise, the temp table you just spent three hours building will be lost and it will do it again.

            IF @logging = 1
            BEGIN
                EXEC EDDSQoS.eddsdbo.QoS_LogAppend @EDDSPerformanceServer = @EDDSPerformanceServer,
                    @runStartUTC = @runStart,
                    @AgentID = @AgentID,
					@module = 'QoS_WorkspaceAnalysis',
                    @taskCompleted = 'QoS_Bullfrog call to collect word counts in all conditions complete',
                    @nextTask = 'Run Bullfrog CTEs, concatenate word list from value conditions.'
            END

            ;WITH getWordCountConditions AS (
				SELECT
					ssc.ArtifactID,
					COUNT(ssc.ArtifactID) gwccCount
                FROM eddsdbo.QoS_SSComplexityAnalysis ssca WITH(NOLOCK)
                RIGHT JOIN eddsdbo.QoS_SSComplexity ssc WITH(NOLOCK)
					ON ssc.VRHID = ssca.VRHID
						AND ssca.SearchArtifactID = ssc.ArtifactID
                RIGHT JOIN eddsdbo.QoS_BullfrogIDCWords BIDCW WITH(NOLOCK)
					ON ssc.VRHID = BIDCW.VRHID
						AND ssc.viewCriteriaID = BIDCW.IDConsumable
                INNER JOIN eddsdbo.QoS_BullfrogWork bfw WITH(NOLOCK)
					ON ssc.VRHID = BIDCW.VRHID
						AND BIDCW.KBWID = bfw.KBWID
                WHERE ssc.VRHID = @VSRunScope
                GROUP BY ssc.ArtifactID
            )
            UPDATE ssca
            SET QTYConditionValueWords = gwcc.gwccCount
            FROM eddsdbo.QoS_SSComplexityAnalysis ssca WITH(NOLOCK)
            INNER JOIN getWordCountConditions gwcc
				ON ssca.SearchArtifactID = gwcc.ArtifactID
			WHERE ssca.VRHID = @VSRunScope

            ;WITH getIsLikePenalty AS (
				SELECT
					ssc.ArtifactID,
                    COUNT(ssc.ArtifactID) * 10 gilpPenalty
                FROM eddsdbo.QoS_SSComplexityAnalysis ssca WITH(NOLOCK)
                RIGHT JOIN eddsdbo.QoS_SSComplexity ssc WITH(NOLOCK)
					ON ssc.VRHID = ssca.VRHID
						AND ssca.SearchArtifactID = ssc.ArtifactID
                RIGHT JOIN eddsdbo.QoS_BullfrogIDCWords BIDCW WITH(NOLOCK)
					ON ssc.VRHID = BIDCW.VRHID
						AND ssc.viewCriteriaID = BIDCW.IDConsumable
                INNER JOIN eddsdbo.QoS_BullfrogWork bfw WITH(NOLOCK)
					ON ssc.VRHID = bfw.VRHID
						AND BIDCW.KBWID = bfw.KBWID
                WHERE ssc.VRHID = @VSRunScope
                    AND Operator = 'like'
                GROUP BY ssc.ArtifactID
                )
            UPDATE ssca
            SET totalSearchComplexityScore = gilp.gilpPenalty + ISNULL(totalSearchComplexityScore, 0)
            FROM eddsdbo.QoS_SSComplexityAnalysis ssca WITH(NOLOCK)
            INNER JOIN getIsLikePenalty gilp
				ON ssca.SearchArtifactID = gilp.ArtifactID
			WHERE ssca.VRHID = @VSRunScope

			;WITH setupForConcat AS (
				SELECT ssc.ArtifactID AS artifactID ,
					Word
                FROM eddsdbo.QoS_SSComplexityAnalysis ssca WITH(NOLOCK)
                RIGHT JOIN eddsdbo.QoS_SSComplexity ssc WITH(NOLOCK)
					ON ssc.VRHID = ssca.VRHID
						AND ssca.SearchArtifactID = ssc.ArtifactID
                RIGHT JOIN eddsdbo.QoS_BullfrogIDCWords BIDCW WITH(NOLOCK)
					ON ssc.VRHID = BIDCW.VRHID
						AND ssc.viewCriteriaID = BIDCW.IDConsumable
                INNER JOIN eddsdbo.QoS_BullfrogWork bfw WITH(NOLOCK)
					ON ssc.VRHID = bfw.VRHID
						AND BIDCW.KBWID = bfw.KBWID
                WHERE ssc.VRHID = @VSRunScope
            )
			UPDATE ssca
			SET ConditionValue = gilp.StuffList
			FROM eddsdbo.QoS_SSComplexityAnalysis ssca WITH(NOLOCK)
			INNER JOIN (
				SELECT ArtifactID,
					STUFF((SELECT '| ' + Word
							FROM setupForConcat
							WHERE (ArtifactID = this.ArtifactID)
							FOR XML PATH('')
						), 1, 1, '') AS StuffList
				FROM setupForConcat AS This
				GROUP BY artifactID
			) gilp
				ON ssca.SearchArtifactID = gilp.artifactID
			WHERE ssca.VRHID = @VSRunScope

			--begin review of Search Text condition

            IF @logging = 1
            BEGIN
				SET @LoggingVars = 'Exec EDDSDBO.QoS_Bullfrog 
					@fieldConsumable =''ParsedSearchText'',
					@tableConsumable = ''eddsdbo.QoS_SSComplexityAnalysis'',
					@IDConsumable = ''SearchArtifactID'',
					@wordBreak = '' ''
					,@excludeWords = ''''
					--other stuff
					,@EDDSPerformanceServer = ' + @EDDSPerformanceServer + '
					,@@AgentID = ' + CAST(@AgentID AS VARCHAR) + '
					,@VSRunID = ' + CAST(@VSRunScope AS VARCHAR) + '
					,@Batchsize = 1000
					,@logging = 1
					,@withResume = 0'
                EXEC EDDSQoS.eddsdbo.QoS_LogAppend
					@EDDSPerformanceServer = @EDDSPerformanceServer,
                    @runStartUTC = @runStart,
                    @AgentID = @AgentID,
					@module = 'QoS_WorkspaceAnalysis',
                    @taskCompleted = 'Ran Bullfrog CTEs, concatenate word list from value conditions.',
                    @otherVars = @LoggingVars,
                    @nextTask = 'Execute QoS_Bullfrog on ParsedSearchText'
            END

            EXEC eddsdbo.QoS_Bullfrog --pass in whatever user configurable settings we want, here.  
                @fieldConsumable = 'ParsedSearchText',
                @tableConsumable = 'eddsdbo.QoS_SSComplexityAnalysis',
                @IDConsumable = 'SearchArtifactID',  -- input of the field name on the document table to be worked on. This is the column that will be consumed
                @wordBreak = ' ', -- this is the delimiters, which accepts a single delimiter (future version to accept a comma delimited list of delimiters)
                @excludeWords = '', -- Use a pipe delimiter for noise words!
				--other stuff
                @EDDSPerformanceServer = @EDDSPerformanceServer,
                @AgentID = @AgentID,
                @VSRunID = @VSRunScope, @Batchsize = 1000,
                @logging = 1, -- for both carving and for the preload phase, this is the size of the transaction that will be committed.  For the preload phase, this is the size of the actual number of rows that will be inserted into the temp table to be worked on.  
                @withResume = 0 --Resume the operation. OK, so, if for some reason your attempt fails and you want it to pickup where you left off, set this to '1'.  Otherwise, the temp table you just spent three hours building will be lost and it will do it again.

            IF @logging = 1
            BEGIN
                EXEC EDDSQoS.eddsdbo.QoS_LogAppend @EDDSPerformanceServer = @EDDSPerformanceServer,
                    @runStartUTC = @runStart,
                    @AgentID = @AgentID,
					@module = 'QoS_WorkspaceAnalysis',
                    @taskCompleted = 'QoS_Bullfrog call to analyze parsed search text complete',
                    @nextTask = 'Run Bullfrog CTEs to update SearchText QTYsearchTextWords field in QoS_SSComplexityAnalysis table.'
            END

			;WITH getWordCountConditions2 AS (
				SELECT
					SearchArtifactID,
					COUNT(SearchArtifactID) AS wordCount
                FROM eddsdbo.QoS_SSComplexityAnalysis ssca WITH(NOLOCK)
                INNER JOIN eddsdbo.QoS_BullfrogIDCWords BIDCW WITH(NOLOCK)
					ON ssca.VRHID = BIDCW.VRHID
						AND BIDCW.IDConsumable = ssca.SearchArtifactID
                RIGHT JOIN eddsdbo.QoS_BullfrogWork bfw WITH(NOLOCK)
					ON ssca.VRHID = bfw.VRHID
						AND bfw.IDConsumable = BIDCW.IDConsumable
				WHERE ssca.VRHID = @VSRunScope
                GROUP BY ssca.SearchArtifactID
            )
            UPDATE ssca
            SET QTYConditionValueWords = wordcount
            FROM eddsdbo.QoS_SSComplexityAnalysis ssca WITH(NOLOCK)
            INNER JOIN getWordCountConditions2 gwcc2
				ON gwcc2.SearchArtifactID = ssca.SearchArtifactID
			WHERE ssca.VRHID = @VSRunScope

            IF @logging = 1
            BEGIN
                EXEC EDDSQoS.eddsdbo.QoS_LogAppend @EDDSPerformanceServer = @EDDSPerformanceServer,
                    @runStartUTC = @runStart,
                    @AgentID = @AgentID,
					@module = 'QoS_WorkspaceAnalysis',
                    @taskCompleted = 'Run Bullfrog CTEs, concatenate word list from value conditions.',
                    @nextTask = 'Analyze and quantify search conditions, updates to QoS_SSComplexityAnalysis table'
            END

			--Step 14 QTYItemsiniFTS Set the ComplexityAnalysis column to this value for use in scoring.
            UPDATE eddsdbo.QoS_SSComplexityAnalysis
            SET QTYItemsIniFTS = @ItemsIniFTS
			WHERE VRHID = @VSRunScope

			--Step 15. QTYsearchTextWords : This parses the parsedSearchText and delimits it based on spaces and commas only.  From there, 
			--it determines how many words are in the searchtext field for a search.  
			--this should be a bullfrog call...
            UPDATE eddsdbo.QoS_SSComplexityAnalysis
            SET QTYsearchTextWords = CASE
					WHEN LEN(ParsedSearchText) > 0 AND isFullTextSearch IS NULL
						THEN (LEN(ParsedSearchText)
								- LEN(REPLACE(
										(REPLACE(ParsedSearchText, ',', ' ')),
										' ', '')
									) + 1 )
					WHEN isFullTextSearch = 1
						THEN (LEN(ParsedSearchText)
								- LEN(REPLACE(
										(REPLACE(ParsedSearchText, ',', ' ')),
										' ', '')
									) + 1)
					END
            WHERE VRHID = @VSRunScope
		
			--Step 16. dtSearchTextLength sets this column to the length of the dtsearch text.
            UPDATE eddsdbo.QoS_SSComplexityAnalysis
            SET dtSearchTextLength = LEN(ParsedSearchText)
            WHERE VRHID = @VSRunScope
				AND ParsedSearchText IS NOT NULL
				AND IsDTsearch = 1
	
			--Step 17. Quantity folders selected to search.
			--TODO: look and see if the search is including subfolders or not.
            UPDATE eddsdbo.QoS_SSComplexityAnalysis
            SET QTYFolderedSearch = (
					SELECT COUNT(folderArtifactID)
                    FROM eddsdbo.SearchFolder WITH(NOLOCK)
                    WHERE eddsdbo.QoS_SSComplexityAnalysis.SearchArtifactID = SearchFolder.SearchArtifactID
                    GROUP BY SearchArtifactID
                ),
                QTYNonLikes = (
					SELECT COUNT(Operator)
                    FROM eddsdbo.QoS_SSComplexity WITH(NOLOCK)
                    WHERE VRHID = @VSRunScope
						AND Operator NOT IN ('IN', 'Contains', 'like')
						AND Operator IS NOT NULL
						AND eddsdbo.QoS_SSComplexityAnalysis.SearchArtifactID = eddsdbo.QoS_SSComplexity.ArtifactID
                ),
				QTYOrderBy = (
					SELECT COUNT(ViewID)
                    FROM eddsdbo.ViewOrder VO WITH(NOLOCK)
                    WHERE eddsdbo.QoS_SSComplexityAnalysis.SearchArtifactID = VO.ViewID
                    GROUP BY ViewID
                )
			WHERE VRHID = @VSRunScope

			--Step 18 is imaginary
			--Step 19: get the types of fields that are being searched.
            SET @o = 1
			SET @counto = -1;

            SELECT
				@o = MIN(ArtifactID),
				@counto = MAX(ArtifactID)
            FROM eddsdbo.QoS_SSComplexity WITH(NOLOCK)
            WHERE VRHID = @VSRunScope
				AND viewCriteriaID IS NOT NULL

            IF @logging = 1
			BEGIN
				EXEC EDDSQoS.eddsdbo.QoS_LogAppend
					@EDDSPerformanceServer = @EDDSPerformanceServer,
					@runStartUTC = @runStart,
					@AgentID = @AgentID,
					@module = 'QoS_WorkspaceAnalysis',
					@taskCompleted = 'Updated QoS_SSComplexityAnalysis',
					@nextTask = 'Analyze and quantify search conditions'
			END	

            WHILE @o <= @counto
			BEGIN
				--the purpose of this is to gather a listing of all of the field search and order by types being used, drawing from the FieldType table to make the assessment
				--capture the order by field types into a single string.  This works one search at a time to coalesce all of a search's field names, types, and order by types into three separate fields. 		
                SELECT @StringFieldOrderByTypes = COALESCE(@StringFieldOrderByTypes + ' | ', '')
                    + CAST(list.OrderbyTypez AS NVARCHAR)
                FROM (
					SELECT kft.FieldType AS OrderbyTypez
                    FROM eddsdbo.QoS_SSComplexity kssc WITH(NOLOCK)
                    RIGHT OUTER JOIN eddsdbo.ViewOrder vo WITH (NOLOCK)
						ON kssc.ArtifactID = vo.ViewID
                    INNER JOIN eddsdbo.[Field] f WITH(NOLOCK)
						ON vo.ArtifactViewFieldID = f.ArtifactViewFieldID
                    INNER JOIN EDDSQoS.eddsdbo.QoS_FieldType kft WITH(NOLOCK)
						ON f.FieldTypeID = kft.FieldTypeID
                    WHERE kssc.VRHID = @VSRunScope
						AND kssc.ArtifactID = @o
                        AND SearchFieldTypeID IS  NULL
                ) list
	
				--Add in the order by fields to the searchFields calculation. At the moment I am using DisplayName cuz I don't remember where the actual name is stored. Its not even in the extended field view.
                UPDATE eddsdbo.QoS_SSComplexityAnalysis
                SET OrderedByFields = COALESCE(@StringSearchFieldNames + ' , ', '')
                        + CAST(list.Orderbyfields AS NVARCHAR)
                FROM (
					SELECT f.DisplayName AS Orderbyfields
                    FROM eddsdbo.QoS_SSComplexity kssc WITH(NOLOCK)
                    RIGHT OUTER JOIN eddsdbo.ViewOrder vo WITH(NOLOCK)
						ON kssc.ArtifactID = vo.ViewID
                    INNER JOIN eddsdbo.[Field] f WITH(NOLOCK)
						ON vo.ArtifactViewFieldID = f.ArtifactViewFieldID
                    WHERE kssc.VRHID = @VSRunScope
						AND kssc.ArtifactID = @o
                        AND SearchFieldTypeID IS  NULL
                ) list
				WHERE VRHID = @VSRunScope
					AND SearchArtifactID = @o;

                UPDATE eddsdbo.QoS_SSComplexityAnalysis
                SET QTYOrderBy = (
					SELECT COUNT(f.DisplayName) AS QTYOrderbyfields
                    FROM eddsdbo.QoS_SSComplexity kssc WITH(NOLOCK)
                    RIGHT OUTER JOIN eddsdbo.ViewOrder vo WITH(NOLOCK)
						ON kssc.ArtifactID = vo.ViewID
                    INNER JOIN eddsdbo.[Field] f WITH(NOLOCK)
						ON vo.ArtifactViewFieldID = f.ArtifactViewFieldID
                    WHERE kssc.VRHID = @VSRunScope
						AND kssc.ArtifactID = @o
                        AND SearchFieldTypeID IS  NULL
                )
				WHERE VRHID = @VSRunScope
					AND SearchArtifactID = @o;

                UPDATE eddsdbo.QoS_SSComplexityAnalysis
                SET QtyOrderByIndexed = (
					SELECT COUNT(avf.ColumnName) AS QTYOrderbyfields
                    FROM eddsdbo.QoS_SSComplexity kssc WITH ( NOLOCK )
                    RIGHT OUTER JOIN eddsdbo.ViewOrder vo WITH(NOLOCK)
						ON kssc.ArtifactID = vo.ViewID
                    INNER JOIN eddsdbo.artifactviewField avf WITH(NOLOCK)
						ON vo.ArtifactViewFieldID = avf.ArtifactViewFieldID
                    WHERE VRHID = @VSRunScope
						AND kssc.ArtifactID = @o
                        AND SearchFieldTypeID IS  NULL
                        AND avf.ColumnName IN (
							SELECT DISTINCT sc.name [field name]
                            FROM sys.indexes si
                            INNER JOIN sys.index_columns ic
								ON si.object_id = ic.object_id
									AND si.index_id = ic.index_id
                            INNER JOIN sys.columns sc
								ON ic.object_id = sc.object_id
									AND ic.column_id = sc.column_id
                            WHERE si.object_id = OBJECT_ID('EDDSDBO.document')
						)
						AND avf.ColumnName NOT IN ('ExtractedText', 'OCRText') --these are fields where one would never expect to see an index and where an index is undesirable.
                    )
                WHERE VRHID = @VSRunScope
					AND SearchArtifactID = @o

                SET @StringSearchFieldNames = ''

                UPDATE eddsdbo.QoS_SSComplexityAnalysis
                SET OrderedByFieldTypes = @StringFieldOrderByTypes
                WHERE VRHID = @VSRunScope
					AND SearchArtifactID = @o

				--capture all the field types that are being searched on as conditions. 
                SELECT @StringSearchFieldTypes = COALESCE(@StringSearchFieldTypes + ' | ', '')
					+ CAST(list.allFieldTypez AS NVARCHAR)
                FROM (
					SELECT kft.FieldType AS allFieldTypez
                    FROM eddsdbo.QoS_SSComplexity kssc WITH(NOLOCK)
                    INNER JOIN EDDSQoS.eddsdbo.QoS_FieldType kft WITH(NOLOCK)
						ON kssc.SearchFieldTypeID = kft.FieldTypeID
                    WHERE kssc.VRHID = @VSRunScope
						AND ArtifactID = @o
                ) list

                UPDATE eddsdbo.QoS_SSComplexityAnalysis
                SET SearchFieldTypes = @StringSearchFieldTypes
                WHERE VRHID = @VSRunScope
					AND SearchArtifactID = @o

				--VARSCAT preloads the field name used in each condition into the kssc table, hit that to coalesce it.
                SELECT @StringSearchFieldNames = COALESCE(@StringSearchFieldNames + ' | ', '')
					+ CAST(list.allFieldNamez AS NVARCHAR)
                FROM (
					SELECT ColumnName AS allFieldNamez
                    FROM eddsdbo.QoS_SSComplexity WITH(NOLOCK)
                    WHERE VRHID = @VSRunScope
						AND ArtifactID = @o
                ) list

                UPDATE eddsdbo.QoS_SSComplexityAnalysis
                SET SearchFieldNames = @StringSearchFieldNames
                WHERE VRHID = @VSRunScope
					AND SearchArtifactID = @o

				--How many of the fields have indexes?
				--TODO: Review execution plan and index/revise accordingly
                UPDATE eddsdbo.QoS_SSComplexityAnalysis
                SET QTYIndexedSearchFields += (
					SELECT COUNT(ColumnName)
                    FROM eddsdbo.QoS_SSComplexity WITH(NOLOCK)
                    WHERE VRHID = @VSRunScope
						AND ColumnName IN (
							SELECT DISTINCT sc.name [field name]
							FROM sys.indexes si
							INNER JOIN sys.index_columns ic
								ON si.object_id = ic.object_id
									AND si.index_id = ic.index_id
							INNER JOIN sys.columns sc
								ON ic.object_id = sc.object_id
									AND ic.column_id = sc.column_id
							WHERE si.object_id = OBJECT_ID('EDDSDBO.document')
						)
						AND ColumnName NOT IN ('ExtractedText', 'OCRText') --these are fields where one would never expect to see an index and where an index is undesirable.
					)
                WHERE VRHID = @VSRunScope
					AND SearchArtifactID = @o

                UPDATE eddsdbo.QoS_SSComplexityAnalysis
                SET QTYSearchFields = (
					SELECT COUNT(ColumnName)
                    FROM eddsdbo.QoS_SSComplexity WITH(NOLOCK)
                    WHERE VRHID = @VSRunScope
						AND ColumnName IS NOT NULL
                )
                WHERE VRHID = @VSRunScope
					AND SearchArtifactID = @o
	
				--get the next search
				SET @o = ISNULL((
					SELECT TOP 1 ArtifactID
					FROM eddsdbo.QoS_SSComplexity WITH(NOLOCK)
					WHERE VRHID = @VSRunScope
						AND viewCriteriaID IS NOT NULL
						AND ArtifactID > @o
					ORDER BY ArtifactID ASC
				), @counto + 1);
	
                SET @StringFieldOrderByTypes = ''
                SET @StringSearchFieldTypes = ''
                SET @StringSearchFieldNames = ''
            END

            IF @logging = 1
            BEGIN
                EXEC EDDSQoS.eddsdbo.QoS_LogAppend @EDDSPerformanceServer = @EDDSPerformanceServer,
                    @runStartUTC = @runStart,
                    @AgentID = @AgentID,
					@module = 'QoS_WorkspaceAnalysis',
                    @taskCompleted = 'Analyzed and quantified search conditions',
                    @nextTask = 'Begin updates for QTYSubSearches, LongestRunTime, ShortestRunTime, TotalLRQRunTime, LastQueryForm,LongestRunningQueryForm, NumCancelled, NumErrored, totalSearchComplexityScore'
            END	

            UPDATE ssca
            SET --Analyze total Search In Searches for the search that reside AT THE SEARCH NODE LEVEL.  This does not include sub searches in the sub searches. See Step 21 for that.
				QTYSubSearches = (
					SELECT COUNT(Operator)
                    FROM eddsdbo.QoS_SSComplexity ssc WITH(NOLOCK)
                    WHERE ssc.VRHID = ssca.VRHID
						AND Operator = 'IN'
						AND ssca.SearchArtifactID = ssc.ArtifactID
                    GROUP BY ArtifactID
                ),
				--get longest, shortest and total running LRQ times for each view/search. and the total runtime for the day of that search. 
                LongestRunTime = (
					SELECT MAX(ExecutionTime)
                    FROM eddsdbo.QoS_SearchAuditRows sar WITH(NOLOCK)
                    WHERE sar.VRHID = ssca.VRHID
						AND sar.ArtifactID = ssca.SearchArtifactID
                        AND ExecutionTime IS NOT NULL
                ),
                ShortestRunTime = (
					SELECT MIN(ExecutionTime)
                    FROM eddsdbo.QoS_SearchAuditRows sar WITH(NOLOCK)
                    WHERE sar.VRHID = ssca.VRHID
						AND sar.ArtifactID = ssca.SearchArtifactID
                        AND ExecutionTime IS NOT NULL
                ),
                TotalLRQRunTime = (
					SELECT SUM(ISNULL(ExecutionTime, 0))
                    FROM eddsdbo.QoS_SearchAuditRows sar WITH(NOLOCK)
                    WHERE sar.VRHID = ssca.VRHID
						AND sar.ArtifactID = ssca.SearchArtifactID
                ),
				--Get query details from last run of the query
				--top 1 will work because eddsdbo.kIESearchAuditRows is ordered by ID descending
                LastQueryForm = (
					SELECT TOP 1 Details
                    FROM eddsdbo.QoS_SearchAuditRows sar WITH(NOLOCK)
                    WHERE sar.VRHID = ssca.VRHID
						AND  sar.ArtifactID = ssca.SearchArtifactID
                    ORDER BY AuditID DESC
                ),
				--Get query details from longest running form of the query
				--top 1 works here because we are sorting by ExecutionTime descending with this statement
                LongestRunningQueryForm = (
					SELECT TOP 1 Details
                    FROM eddsdbo.QoS_SearchAuditRows sar WITH(NOLOCK)
                    WHERE sar.VRHID = ssca.VRHID
						AND sar.ArtifactID = ssca.SearchArtifactID
                    ORDER BY ExecutionTime DESC
                ),
				--Determine how many times the query was cancelled or threw an error
                NumCancelled = (
					SELECT COUNT(*)
                    FROM eddsdbo.QoS_SearchAuditRows sar WITH(NOLOCK)
                    WHERE sar.VRHID = ssca.VRHID
						AND sar.ArtifactID = ssca.SearchArtifactID
                        AND sar.Details LIKE '%<cancelled>%'
                ),
                NumErrored = (
					SELECT COUNT(*)
                    FROM eddsdbo.QoS_SearchAuditRows sar WITH(NOLOCK)
                    WHERE sar.VRHID = ssca.VRHID
						AND sar.ArtifactID = ssca.SearchArtifactID
                        AND sar.Details LIKE '%<ErrorMessage>%'
                )
			FROM eddsdbo.QoS_SSComplexityAnalysis ssca
			WHERE VRHID = @VSRunScope

			--All of the results are added up together to come up with a total score for the search.
			--TODO: Review execution plan and optimize accordingly
            UPDATE eddsdbo.QoS_SSComplexityAnalysis
            SET totalSearchComplexityScore = (
				SELECT
					ISNULL(totalSearchComplexityScore, 0)
                )
                + ISNULL(QTYConditionValueWords, 0)
                + ISNULL(searchTextLength, 0)
                + ISNULL(dtSearchTextLength, 0)
                + ISNULL(isFullTextSearch, 0)
                + ISNULL(IsDTsearch, 0)
                + ISNULL(IsSQLSearch, 0)
                + (ISNULL(IsSQLSearch, 0) * ISNULL(QTYFolderedSearch, 0) * ISNULL(QTYNonLikes, 0))
                + ISNULL(QTYOrderBy, 0)
            FROM eddsdbo.QoS_SSComplexityAnalysis ssca WITH(NOLOCK)
			WHERE VRHID = @VSRunScope

            IF @logging = 1
            BEGIN
                EXEC EDDSQoS.eddsdbo.QoS_LogAppend @EDDSPerformanceServer = @EDDSPerformanceServer,
                    @runStartUTC = @runStart,
                    @AgentID = @AgentID,
					@module = 'QoS_WorkspaceAnalysis',
                    @taskCompleted = 'Completed updates for QTYSubSearches, LongestRunTime, ShortestRunTime, TotalLRQRunTime, LastQueryForm,LongestRunningQueryForm, NumCancelled, NumErrored, totalSearchComplexityScore',
                    @nextTask = 'Tally SubSearches'
            END

			--Now, update the score to reflect the sum value of all the subsearches
            BEGIN TRY
				;WITH SubSearchCount AS (
					SELECT SearchArtifactID ,
						DOOP = 0,
                        SearchAsCriteriaArtifactID,
                        [Level] = 1
                    FROM eddsdbo.SearchSavedSearch (NOLOCK)
                    UNION ALL (
                        SELECT sss.SearchArtifactID,
							sss.SearchAsCriteriaArtifactID AS DOOP,
							sss.SearchAsCriteriaArtifactID,
							ssc.[Level] + 1
                        FROM eddsdbo.SearchSavedSearch sss (NOLOCK)
                        INNER JOIN SubSearchCount ssc
							ON ssc.SearchArtifactID = sss.SearchAsCriteriaArtifactID
                    )
				)
                INSERT INTO eddsdbo.QoS_SubSearchCount
					(VRHID, SearchArtifactID, DOOP, SearchAsCriteriaArtifactID, [Level])
				SELECT @VSRunScope,
					SearchArtifactID,
					DOOP,
					SearchAsCriteriaArtifactID,
					[Level]
                FROM SubSearchCount
            END TRY
            BEGIN CATCH
                SET @infoMessage = 'The maximum recursion level was reached when analyzing subsearches.  Subsearch analysis may be inaccurate for this workspace: ' + @workspace
				IF @logging = 1
				BEGIN
					SET @LoggingVars = @infoMessage
					EXEC EDDSQoS.eddsdbo.QoS_LogAppend @EDDSPerformanceServer = @EDDSPerformanceServer,
						@runStartUTC = @runStart,
						@AgentID = @AgentID,
						@module = 'QoS_WorkspaceAnalysis',
						@taskCompleted = 'Tally SubSearches',
						@otherVars = @LoggingVars,
						@nextTask = 'Set Tallies of subsearches in QoS_SSComplexityAnalysis, begin inserts to VarscatOutput table.'
				END
            END CATCH

			--This section aggregates and sums the complexity of the subsearches in a search, and then adds them to the total complexity score.
            UPDATE ksca
            SET totalSearchComplexityScore = totalSearchComplexityScore + sscs.subsearchtotal
            FROM eddsdbo.QoS_SSComplexityAnalysis ksca WITH(NOLOCK)
            INNER JOIN (
				SELECT ssc.SearchArtifactID,
					SUM(ISNULL(kvScat.totalSearchComplexityScore,0)) subsearchtotal
                FROM eddsdbo.QoS_SubSearchCount ssc WITH(NOLOCK)
                INNER JOIN eddsdbo.QoS_SSComplexityAnalysis kvScat WITH(NOLOCK)
				ON ssc.VRHID = kvScat.VRHID
					AND ssc.SearchAsCriteriaArtifactID = kvScat.SearchArtifactID
				WHERE ssc.VRHID = @VSRunScope
                GROUP BY ssc.SearchArtifactID
            ) sscs
				ON ksca.SearchArtifactID = sscs.SearchArtifactID
			WHERE ksca.VRHID = @VSRunScope

			--capture all the adhoc queries and insert them here for later inclusion in the output. these are grouped by total adhoc queries per user.
			--Later, the one that ran the longest, and the most times, is captured. Since this is a primary grouping, and QoS_RSSDUserOutput is a secondary grouping, there is no need to enter these items to there. 
            INSERT INTO EDDSQoS.eddsdbo.QoS_VarscatOutput
                (AgentID, QoSHourID, DatabaseName, SearchName, SearchArtifactID, TotalLRQRunTime, TotalRuns, SummaryDayHour)
            SELECT
				@AgentID,
                @QoSHourID,
                @workspace AS DatabaseName,
                '-- Search Export by RDC --',
                kSAR.ArtifactID,
                SUM(ISNULL(kSAR.ExecutionTime, 0)),
                COUNT(kSAR.UserID) TotalRuns,
                @beginDate
            FROM eddsdbo.QoS_SearchAuditRows kSAR WITH(NOLOCK)
            INNER JOIN eddsdbo.QoS_SearchAuditParsed kSAP WITH(NOLOCK)
				ON kSAR.VRHID = kSAP.VRHID
					AND kSAR.AuditID = kSAP.AuditID
            INNER JOIN eddsdbo.AuditUser AU WITH(NOLOCK)
				ON AU.UserID = kSAR.UserID
            WHERE kSAR.VRHID = @VSRunScope
				AND ArtifactID = @rootWorkspaceArtifactID
                AND kSAR.RequestOrigination LIKE '%relativitywebapi%'
            GROUP BY kSAR.ArtifactID, AU.FullName, AU.UserID
            ORDER BY COUNT(kSAR.UserID) DESC

            INSERT INTO EDDSQoS.eddsdbo.QoS_VarscatOutput
				(AgentID, QoSHourID, DatabaseName, SearchName, SearchArtifactID, TotalLRQRunTime, TotalRuns, SummaryDayHour)
            SELECT
				@AgentID,
                @QoSHourID,
                @workspace AS DatabaseName,
                '-- ad hoc query --',
                kSAR.ArtifactID,
                SUM(ISNULL(kSAR.ExecutionTime, 0)),
                COUNT(kSAR.UserID) TotalRuns,
                @beginDate
            FROM eddsdbo.QoS_SearchAuditRows kSAR WITH(NOLOCK)
            INNER JOIN eddsdbo.QoS_SearchAuditParsed kSAP WITH(NOLOCK)
				ON kSAR.VRHID = kSAP.VRHID
					AND kSAR.AuditID = kSAP.AuditID
            INNER JOIN eddsdbo.AuditUser AU WITH(NOLOCK)
				ON AU.UserID = kSAR.UserID
            WHERE kSAR.VRHID = @VSRunScope
				AND ArtifactID = @rootWorkspaceArtifactID
                AND kSAR.RequestOrigination NOT LIKE '%relativitywebapi%'
            GROUP BY kSAR.ArtifactID

            INSERT INTO EDDSQoS.eddsdbo.QoS_VarscatOutput
				(AgentID, QoSHourID, DatabaseName, SearchName, SearchArtifactID, isCLRQ, totalSearchComplexityScore,
                    LongestRunTime, ShortestRunTime, TotalLRQRunTime, QTYLikeOperators, QTYSubSearches, TotalQTYSubSearches, [QTY Select folders],
                    SearchTextLength, TotalRuns,
                    ParsedSearchText, SearchType, [total words all conditions],
                    dtSearchTextLength, QTYOrderBy,
                    SummaryDayHour)
            SELECT  @AgentID ,
                    @QoSHourID ,
                    @workspace AS DatabaseName ,
                    SearchName ,
                    SearchArtifactID ,
                    '' ,
                    totalSearchComplexityScore ,
                    LongestRunTime ,
                    ShortestRunTime ,
                    TotalLRQRunTime ,
                    COALESCE(QTYLikeOperators,
                                0) ,
                    COALESCE(QTYSubSearches, 0) ,
                    COALESCE(QTYSubSearches, 0)
                    + COALESCE(TotalQTYSubSearches,
                                0) ,
                    COALESCE(QTYFolderedSearch,
                                0) [QTY Select folders] ,
                    COALESCE(searchTextLength,
                                0) ,
                    COALESCE(kRSSDO.TotalRuns,
                                0) ,
                    COALESCE(ParsedSearchText,
                                '') [Search Text] ,
                    'Type of search' = CASE
                                WHEN IsDTsearch = 1
                                THEN 'dtSearch'
                                WHEN CONVERT(INT, IsDTsearch)
                                + CONVERT(INT, IsSQLSearch) = 2
                                THEN 'dt and SQL search'
                                WHEN IsSQLSearch IS NULL
                                THEN 'Full Text Search'
                                WHEN IsSQLSearch = 1
                                THEN 'SQL search'
                                ELSE ''
                                END ,
                    COALESCE(QTYConditionValueWords,
                                0) [total words all conditions] ,
                    COALESCE(dtSearchTextLength,
                                0) ,
                    COALESCE(QTYOrderBy, 0) ,
                    @beginDate
            FROM eddsdbo.QoS_SSComplexityAnalysis kSSCA WITH(NOLOCK)
            LEFT JOIN eddsdbo.QoS_Round2AllSearchzSubSearches ASSS WITH(NOLOCK)
				ON kSSCA.VRHID = ASSS.VRHID
					AND ASSS.ALLSearchz = kSSCA.SearchArtifactID
            LEFT JOIN eddsdbo.QoS_RSSDOutput kRSSDO WITH(NOLOCK)
				ON kSSCA.VRHID = kRSSDO.VRHID
					AND kSSCA.SearchArtifactID = kRSSDO.ArtifactID
			WHERE kSSCA.VRHID = @VSRunScope
            ORDER BY totalSearchComplexityScore DESC

			IF @logging = 1
			BEGIN
				EXEC EDDSQoS.eddsdbo.QoS_LogAppend @EDDSPerformanceServer = @EDDSPerformanceServer,
					@runStartUTC = @runStart,
					@AgentID = @AgentID,
					@module = 'QoS_WorkspaceAnalysis',
					@taskCompleted = 'Set run times, SQL query forms, sub search quantities. Completed inserts into QoS_VarscatOutput.',
					@nextTask = 'Begin the four inserts to VarscatOutputDetail'
			END	

			--PASS 1
			--insert all of the VARSCAT Outputs
			--change the below query to pull the SQL query from SearchAuditParsed instead of SearchAuditRows (join to SearchAuditParsed)
			--SELECT * FROM eddsdbo.QoS_SearchAuditParsed WHERE DetailsParsed like '%<QueryType>Count%'
            INSERT INTO eddsdbo.VarscatOutputDetail
				(VRHID, AgentID, ServerName, QoSHourID, DatabaseName, SearchArtifactID, QueryID, SearchName, AuditID, UserID, ComplexityScore,
					ExecutionTime, [Timestamp], QoSAction, IsComplex)
            SELECT
				@VSRunScope,
				@AgentID,
                @@servername,
                @QoSHourID,
                @workspace,
                kSAR.ArtifactID,
				CASE WHEN CHARINDEX(N'<QueryID>', kSAP.DetailsParsed) != 0
					THEN CAST(SUBSTRING(kSAP.DetailsParsed,
							CHARINDEX(N'<QueryID>', kSAP.DetailsParsed) + 9, --Length of "<QueryID>": 9 characters
							36) as uniqueidentifier) --Length of the QueryID GUID: 36 characters
					ELSE NULL
				END AS QueryID,
                kVO.SearchName,
                kSAR.AuditID,
                kSAR.UserID,
                kVO.totalSearchComplexityScore,
                kSAR.ExecutionTime,
                kSAR.[TimeStamp],
                CASE WHEN kSAP.DetailsParsed LIKE '%<QueryType>Count%' THEN 282
					WHEN kSAP.DetailsParsed LIKE '%<QueryType>Full%' THEN 283
					ELSE 281
                END AS QosAction,
				CASE WHEN kVO.totalSearchComplexityScore > 9 THEN 1
					WHEN kSAP.DetailsParsed LIKE '% LIKE ''%' THEN 1
					WHEN kSAP.DetailsParsed LIKE '% LIKE N''%' THEN 1
					ELSE 0
				END AS IsComplex
            FROM eddsdbo.QoS_SearchAuditRows kSAR WITH(NOLOCK)
			INNER JOIN eddsdbo.QoS_SearchAuditParsed kSAP WITH(NOLOCK)
				ON kSAR.VRHID = kSAP.VRHID
					AND kSAR.AuditID = kSAP.AuditID
            LEFT JOIN EDDSQoS.eddsdbo.QoS_VarscatOutput kVO WITH(NOLOCK)
				ON kSAR.ArtifactID = kVO.SearchArtifactID
					AND kVO.QoSHourID = @QoSHourID
					AND kVO.DatabaseName = @workspace
					AND kVO.AgentID = @AgentID
            WHERE kSAR.VRHID = @VSRunScope

			/* Available fields from QoS_VarscatOutput to be used for complexity analysis:
				TotalQTYSubSearches INT 
				[QTY Select folders] INT, > ?
				SearchTextLength INT : Greater than 500 ,
				QTYOrderBy INT,SummaryDayHour Datetime,
			*/

			--Get all other audits that have execution times.
            INSERT INTO eddsdbo.VarscatOutputDetail
				(VRHID, AgentID, ServerName, QoSHourID, DatabaseName, AuditID, UserID, ExecutionTime, [Timestamp], QoSAction)
            SELECT 
				@VSRunScope,
				@AgentID,
                @@ServerName,
                @QoSHourID,
                @workspace,
                ID,
                UserID,
                ExecutionTime,
                [TimeStamp],
                [Action]
			FROM [eddsdbo].[AuditRecord] WITH(NOLOCK)
			WHERE [Action] IN (1, 29, 32, 34, 35, 37)
                AND [TimeStamp] >= @beginDate
				AND [Timestamp] < @endDate
            OPTION (MAXDOP 2)

			--Get all export audits that have execution times.
            INSERT INTO eddsdbo.VarscatOutputDetail
				(VRHID, AgentID, ServerName, QoSHourID, DatabaseName, AuditID, UserID, ExecutionTime, [Timestamp], QoSAction)
			SELECT 
				@VSRunScope,
				@AgentID,
				@@ServerName,
				@QoSHourID,
				@workspace,
				MIN(ID),
				UserID,
				AVG(ExecutionTime),
				DATEADD(hh, DATEDIFF(hh, 0, [Timestamp]), 0) [TimeStamp],
				33
			FROM [eddsdbo].[AuditRecord] WITH(NOLOCK)
			WHERE [Action] = 33
				AND [TimeStamp] >= @beginDate
			AND [Timestamp] < @endDate
			GROUP BY DATEADD(hh, DATEDIFF(hh, 0, [Timestamp]), 0), [UserID] 
			OPTION (MAXDOP 2)
			
			--Create the '456' audits which is a mash-up of the ( 4, 5, 6 ) audits actions.
			--Since they are being aggregated, by user ID per hour, they are assigned an arbitrary AuditID of 51773.
			--Plan produces an index seek, even across an entire month in the test environment.
			--Separate indexing may be warranted for UserID and Action to optimize this query in the event that a particular hour may have enough audits to trip a scan. The existing index is rather fat.  
            INSERT INTO eddsdbo.VarscatOutputDetail
                (VRHID, AgentID, ServerName, QoSHourID, DatabaseName, AuditID, UserID, ExecutionTime, [Timestamp], QoSAction)
            SELECT
				@VSRunScope,
				@AgentID,
                @@servername,
                @QoSHourID,
                @workspace AS DatabaseName,
                51773,
                UserID,
                COUNT(UserID) * 2 AS executionTime, --estimating concurrency
                @beginDate,
                456
            FROM eddsdbo.AuditRecord WITH ( NOLOCK )
            WHERE [TimeStamp] >= @beginDate
				AND [Timestamp] < @endDate
				AND [Action] IN ( 4, 5, 6 )
            GROUP BY UserID
            OPTION (MAXDOP 2) -- parallelism doubtful if CTP set higher than 10

			--Create the action 47 audits which is an RDC Overlay.  Since they are being aggregated by user ID per hour, they are assigned an arbitrary AuditID of 773.
			--The audits are estimated based on internal testing at kCura, halved.
			INSERT INTO eddsdbo.VarscatOutputDetail
                (VRHID, AgentID, ServerName, QoSHourID, DatabaseName, AuditID, UserID, ExecutionTime, [Timestamp], QoSAction)
            SELECT
				@VSRunScope,
				@AgentID,
                @@servername,
                @QoSHourID,
                @workspace AS DatabaseName,
                773,
                UserID,
                COUNT(UserID) * 10 AS executionTime, --for estimating concurrency. Each overlay audit estimated to .01 seconds, or 10 milliseconds.
                @beginDate,
                47
            FROM eddsdbo.AuditRecord WITH (NOLOCK)
            WHERE [TimeStamp] >= @beginDate
				AND [Timestamp] < @endDate
				AND [Action] = 47
            GROUP BY UserID
            OPTION (MAXDOP 2)

			--For the time being, because action item 3s are also used by RDC during an overlay, this is bring aggregated to prevent swamping the system.
			INSERT INTO eddsdbo.VarscatOutputDetail
				(VRHID, AgentID, ServerName, QoSHourID, DatabaseName, AuditID, UserID, ExecutionTime, [Timestamp], QoSAction)
			SELECT
				@VSRunScope,
				@AgentID,
				@@servername,
				@QoSHourID,
				@workspace AS DatabaseName,
				51773,
				UserID,
				COUNT(UserID) * 2 AS executionTime, --estimating concurrency
				@beginDate,
				456
			FROM eddsdbo.AuditRecord WITH ( NOLOCK )
			WHERE [TimeStamp] >= @beginDate
				AND [Timestamp] < @endDate
				AND [Action] = 3
			GROUP BY UserID
            OPTION (MAXDOP 2) -- parallelism doubtful if CTP set higher than 10 

			--Second Pass, massage values
			UPDATE eddsdbo.VarscatOutputDetail
			SET IsComplex = 1
			WHERE ComplexityScore > 9
				AND DatabaseName = @workspace
				AND QoSHourID = @QoSHourID

			--set isLongRunning
            UPDATE eddsdbo.VarscatOutputDetail
            SET IsLongRunning = (
					CASE WHEN ExecutionTime > 2000 AND IsComplex = 0 THEN 1
							WHEN ExecutionTime > 8000 AND IsComplex = 1 THEN 1
							ELSE 0
					END
				)
            WHERE QoSAction IN ( 281, 282, 283 )
				AND DatabaseName = @workspace
				AND QoSHourID = @QoSHourID
                                            
            IF @logging = 1
            BEGIN
                EXEC EDDSQoS.eddsdbo.QoS_LogAppend @EDDSPerformanceServer = @EDDSPerformanceServer,
                    @runStartUTC = @runStart,
                    @AgentID = @AgentID,
					@module = 'QoS_WorkspaceAnalysis',
                    @taskCompleted = 'Completed detailed output',
                    @nextTask = 'Inserting detailed output to EDDSQoS'
            END	
                                            
            INSERT INTO EDDSQoS.eddsdbo.QoS_VarscatOutputDetail
				(ServerName, QoSHourID, DatabaseName, SearchArtifactID, SearchName, AuditID, UserID,
				ComplexityScore, ExecutionTime, [Timestamp], QoSAction,
				IsComplex, IsLongRunning, AgentID, QueryID)
            SELECT 
				ServerName,
				QoSHourID,
				DatabaseName,
				SearchArtifactID,
				SearchName,
				AuditID,
				UserID,
				ComplexityScore,
				ExecutionTime,
				[Timestamp],
				QoSAction,
				IsComplex,
				IsLongRunning,
				AgentID,
				QueryID
            FROM eddsdbo.VarscatOutputDetail WITH(NOLOCK)
			WHERE QoSHourID = @QoSHourID
				AND VRHID = @VSRunScope

			SET @o = @@ROWCOUNT;

			IF @logging = 1
            BEGIN
                SET @LoggingVars = 'Rows inserted: ' + ISNULL(CAST(@o as varchar(max)), 'NULL') + ', @QoSHourID = ' + ISNULL(CAST(@QoSHourID as varchar(max)), 'NULL') + ', @VSRunScope = ' + ISNULL(CAST(@VSRunScope AS varchar(max)), 'NULL')
                EXEC EDDSQoS.eddsdbo.QoS_LogAppend @EDDSPerformanceServer = @EDDSPerformanceServer,
                    @runStartUTC = @runStart,
                    @AgentID = @AgentID,
					@module = 'QoS_WorkspaceAnalysis',
                    @taskCompleted = 'Completed inserts/updates to VarscatOutputDetail',
                    @otherVars = @LoggingVars,
                    @nextTask = 'Deleting transient run data'
            END
        END

		UPDATE eddsdbo.QoS_VarscatRunHistory
		SET IsActive = 0
		WHERE VRHID = @VSRunScope
    END TRY
    BEGIN CATCH
        UPDATE eddsdbo.QoS_VarscatRunHistory
        SET IsActive = 0
        WHERE VRHID = @VSRunScope

        IF @logging = 1
        BEGIN
            SET @LoggingVars = 'Varscat failed during execution: ' + ERROR_MESSAGE()
            EXEC EDDSQoS.eddsdbo.QoS_LogAppend @EDDSPerformanceServer = @EDDSPerformanceServer,
                @runStartUTC = @runStart,
                @AgentID = @AgentID,@module = 'QoS_WorkspaceAnalysis',
                @taskCompleted = 'Run Attempt, raising error.',
                @otherVars = @LoggingVars,
                @nextTask = 'Post-run cleanup'
            RAISERROR(@LoggingVars, 11, 1)
        END
    END CATCH

	

	/* We will attempt to clean out data from old runs. The last run's data will always be preserved so that it can be inspected. */
	BEGIN TRY
		SET DEADLOCK_PRIORITY LOW

		DELETE FROM eddsdbo.QoS_VarscatRunHistory
		WHERE VRHID != @VSRunScope
			AND (IsActive = 0
				 OR DATEADD(hh, 1, RunDateTimeUTC) < GETUTCDATE() --get rid of stale entries
			)

		SET @historyKeepThreshold = ISNULL((
				SELECT MIN(VRHID)
				FROM eddsdbo.QoS_VarscatRunHistory WITH(NOLOCK)
			),
			@VSRunScope
		)

		DELETE FROM eddsdbo.VarscatOutputDetail
		WHERE VRHID < @historyKeepThreshold;

		DELETE FROM eddsdbo.QoS_BullfrogIDCWords
		WHERE VRHID < @historyKeepThreshold;

		DELETE FROM eddsdbo.QoS_BullfrogWork
		WHERE VRHID < @historyKeepThreshold;

		DELETE FROM [EDDSDBO].QoS_BullfrogWords
		WHERE VRHID < @historyKeepThreshold;

		DELETE FROM eddsdbo.QoS_ALLSearchzSubSearches
		WHERE VRHID < @historyKeepThreshold;

		DELETE FROM eddsdbo.QoS_thisSearchzSubSearches
		WHERE VRHID < @historyKeepThreshold;

		DELETE FROM eddsdbo.QoS_thisSearchzSubSearchesTemp
		WHERE VRHID < @historyKeepThreshold;

		DELETE FROM eddsdbo.QoS_Round2AllSearchzSubSearches
		WHERE VRHID < @historyKeepThreshold;

		DELETE FROM eddsdbo.QoS_SearchAuditRows
		WHERE VRHID < @historyKeepThreshold;

		DELETE FROM eddsdbo.QoS_SearchAuditParsed
		WHERE VRHID < @historyKeepThreshold;

		DELETE FROM eddsdbo.QoS_RSSDOutput
		WHERE VRHID < @historyKeepThreshold;

		DELETE FROM eddsdbo.QoS_RSSDUserOutput
		WHERE VRHID < @historyKeepThreshold;

		DELETE FROM eddsdbo.QoS_SSComplexity
		WHERE VRHID < @historyKeepThreshold;

		DELETE FROM eddsdbo.QoS_SSComplexityAnalysis
		WHERE VRHID < @historyKeepThreshold;

		DELETE FROM eddsdbo.QoS_vScAT_examinedSearchz
		WHERE VRHID < @historyKeepThreshold;

		DELETE FROM eddsdbo.QoS_SubSearchCount
		WHERE VRHID < @historyKeepThreshold;

		IF @logging = 1
		BEGIN
			SET @LoggingVars = @SQL
			EXEC EDDSQoS.eddsdbo.QoS_LogAppend
				@EDDSPerformanceServer = @EDDSPerformanceServer,
				@runStartUTC = @runStart,
				@AgentID = @AgentID,
				@module = 'QoS_WorkspaceAnalysis',
				@taskCompleted = 'Finished post-run cleanup',
				@otherVars = @LoggingVars
		END
	END TRY
	BEGIN CATCH
		IF @logging = 1
		BEGIN
			SET @LoggingVars = @SQL
			EXEC EDDSQoS.eddsdbo.QoS_LogAppend
				@EDDSPerformanceServer = @EDDSPerformanceServer,
				@runStartUTC = @runStart,
				@AgentID = @AgentID,
				@module = 'QoS_WorkspaceAnalysis',
				@taskCompleted = 'Skipped post-run cleanup',
				@otherVars = @LoggingVars
		END
	END CATCH
END